# Entertainment Hub — PHP backend + authentication

Frontend ab **localStorage** ki jagah PHP backend se chalta hai. Requirements: **PHP 8.1+** with `pdo_sqlite` (ya `pdo_mysql`), `mbstring`, `gd`/`fileinfo` (image check ke liye).

## Local pe chalana

```bash
cd entertainment-hub
php -S localhost:8000
```

Phir browser mein kholo: `http://localhost:8000/admin/login.html`

**Pehli baar** login page apne aap "Set up your admin account" form dikhayega — wahin se super admin banao.
(Koi default `admin / admin123` password nahi hai.)

> Files ko seedha double-click karke (file://) mat kholo — PHP chalna zaroori hai.

## Kya-kya bana hai

| Cheez | Kaise kaam karti hai |
|---|---|
| Login / Logout | PHP session (HttpOnly + SameSite cookie, HTTPS pe Secure), login pe session ID regenerate |
| Passwords | `password_hash` (Argon2id) — plain password kahin store nahi hota, signup requests mein bhi nahi |
| Brute-force protection | 5 galat attempts / 15 min par lockout (IP + username), username enumeration nahi hota |
| CSRF | Har POST pe token + Origin check |
| Roles | `superadmin` (sab kuch) aur `subadmin` (content manage, Settings nahi) — **server pe enforce**, sirf UI hide nahi |
| Sub-admin signup | Login page se request → Settings mein super admin Approve/Decline |
| Disable / Remove / Password change | Turant effect: us account ke live sessions logout ho jaate hain |
| Content (team, slides, blogs, gallery, analytics, live stream) | Database mein JSON sections; server validate karta hai |
| Images | Admin forms jo base64 bhejte hain, server unhe real file bana kar `uploads/` mein rakhta hai (sirf JPG/PNG/GIF/WebP, content check ke saath; SVG/PHP reject) |
| Public website | `api/public.js.php` se sirf publish hone wala data (users/analytics/settings nahi) |

## Folder structure

```
api/
  index.php          JSON API (login, save, users ...)
  session.js.php     admin pages ke liye bootstrap (session + CSRF + content)
  public.js.php      public pages ke liye bootstrap
  config.php         settings (env variables se override)
  reset-password.php CLI se password reset (web se nahi chalta)
  lib/               db, auth, content, uploads, http helpers
data/                SQLite database (web se blocked)
uploads/             uploaded images (yahan PHP execute nahi hota)
admin/               admin panel (login.html se shuru)
```

## Configuration (environment variables)

| Variable | Matlab |
|---|---|
| `EH_DB_DSN`, `EH_DB_USER`, `EH_DB_PASS` | MySQL ke liye, jaise `mysql:host=localhost;dbname=hub;charset=utf8mb4` |
| `EH_SETUP_KEY` | Set karoge to first-run form ye key bhi maangega (server pe deploy karte waqt **recommended**) |
| `EH_TRUST_PROXY=1` | Sirf tab jab Cloudflare/nginx proxy ke peeche ho (sahi IP ke liye) |
| `EH_BASE_URL` | Agar auto-detect galat ho, jaise `/entertainment-hub` |
| `EH_SESSION_IDLE` | Idle timeout seconds mein (default 7200) |

## Server pe deploy karte waqt

1. **HTTPS zaroor lagao** (login password plain HTTP pe sniff ho sakta hai).
2. `EH_SETUP_KEY` set karo, phir turant apna super admin bana lo.
3. SQLite file ko web root ke **bahar** rakho: `EH_DB_DSN=sqlite:/home/youruser/private/hub.sqlite`
4. `data/` aur `uploads/` folder PHP user ke liye writable hone chahiye.
5. **Apache**: `.htaccess` files already hain (api/lib, data, uploads protected).
   **nginx** par `.htaccess` kaam nahi karta, ye add karo:

   ```nginx
   location ^~ /data/        { deny all; }
   location ^~ /api/lib/     { deny all; }
   location = /api/reset-password.php { deny all; }
   location ^~ /uploads/ {
       location ~ \.php$ { deny all; }
   }
   client_max_body_size 48M;
   ```
6. Image upload bade hon to `post_max_size` / `upload_max_filesize` badhao (`api/.user.ini` aur `api/.htaccess` mein 48M set hai).

## Password bhool gaye?

Email-reset nahi hai. Server pe terminal se:

```bash
php api/reset-password.php <username>
```

## API (short)

`GET  api/index.php?action=` `session`, `state`, `admin_users`
`POST api/index.php?action=` `setup`, `login`, `logout`, `signup`, `save`, `log`, `account_update`, `password_change`, `request_approve`, `request_deny`, `subadmin_create`, `subadmin_update`, `subadmin_toggle`, `subadmin_delete`, `reset_content`

Saare POST ko header `X-CSRF-Token` chahiye (`window.__EH_BOOT.csrf` mein milta hai).

## Known limitations (seedhi baat)

- **Stored-XSS risk:** admin pages content (title, naam, etc.) `innerHTML` se render karte hain. Isliye sub-admins ko *trusted* maanna — ek malicious sub-admin super admin ke browser mein script chalwa sakta hai. Image URLs aur activity log server pe sanitize hote hain, lekin sahi fix frontend mein output escaping hai.
- Email notifications nahi hain (signup request ka alert, password reset). Settings page par requests dekhte rehna.
- Content ke images delete karne par `uploads/` se purani files apne aap nahi hatti (sirf profile photos hatti hain).
- Analytics/Instagram/Facebook/YouTube numbers abhi bhi demo/manual hain — real APIs ke liye alag OAuth integration chahiye.
