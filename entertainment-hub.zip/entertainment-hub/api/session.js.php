<?php
/**
 * Loaded by every admin page as a normal <script src>. It runs BEFORE the page's own
 * code and defines window.__EH_BOOT (session, CSRF token, and — only when signed in —
 * the site content), so the admin pages can keep working synchronously.
 */
declare(strict_types=1);

require __DIR__ . '/lib/init.php';
init_runtime();

header('Content-Type: application/javascript; charset=utf-8');
header('Cache-Control: no-store, private');

$boot = ['apiUrl' => base_url() . '/api/index.php'];
try {
    start_session();
    $user = current_user();
    $boot += [
        'authenticated'    => $user !== null,
        'user'             => $user ? public_user($user) : null,
        'csrf'             => $_SESSION['csrf'] ?? '',
        'needsSetup'       => needs_setup(),
        'setupKeyRequired' => (string) cfg('setup_key') !== '',
        'allowSignup'      => (bool) cfg('allow_signup_requests'),
    ];
    if ($user) {
        $boot['state'] = build_state();
    }
} catch (Throwable $e) {
    error_log('[entertainment-hub] ' . $e);
    $boot['error'] = 'The server could not start. Check the PHP error log.';
}

echo 'window.__EH_BOOT = ',
    json_encode($boot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_INVALID_UTF8_SUBSTITUTE),
    ';';
