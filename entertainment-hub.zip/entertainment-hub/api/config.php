<?php
/**
 * Backend configuration.
 *
 * Every value can be overridden with an environment variable (EH_*), so you
 * normally do not need to edit this file on a server.
 */
declare(strict_types=1);

$env = static function (string $key, $default) {
    $value = getenv($key);
    return ($value === false || $value === '') ? $default : $value;
};

return [
    // --- Database --------------------------------------------------------
    // Default: SQLite file in /data (zero setup). For MySQL use e.g.
    //   EH_DB_DSN="mysql:host=localhost;dbname=entertainment_hub;charset=utf8mb4"
    //   EH_DB_USER / EH_DB_PASS
    // TIP: on a real server move the SQLite file OUTSIDE the web root.
    'db_dsn'  => $env('EH_DB_DSN', 'sqlite:' . dirname(__DIR__) . '/data/app.sqlite'),
    'db_user' => $env('EH_DB_USER', ''),
    'db_pass' => $env('EH_DB_PASS', ''),

    // --- First-run setup -------------------------------------------------
    // When no super admin exists yet, the login page shows a "create super
    // admin" form. If you set a key here, that form also asks for it, so a
    // stranger who finds the site before you cannot claim the account.
    'setup_key' => $env('EH_SETUP_KEY', ''),

    // --- Sessions --------------------------------------------------------
    'session_name'      => 'EHSESSID',
    'session_idle'      => (int) $env('EH_SESSION_IDLE', 7200),     // 2 hours without activity
    'session_absolute'  => (int) $env('EH_SESSION_ABSOLUTE', 43200), // 12 hours max

    // --- Brute-force protection -----------------------------------------
    'login_max_attempts' => 5,     // failures per (IP + username) ...
    'login_window'       => 900,   // ... within this many seconds => locked out
    'signup_per_hour'    => 5,     // sub-admin requests per IP per hour

    // --- Misc ------------------------------------------------------------
    'allow_signup_requests' => true,
    // Set to true ONLY if you sit behind a trusted reverse proxy (Cloudflare, nginx...)
    'trust_proxy_headers'   => $env('EH_TRUST_PROXY', '') === '1',
    // Public URL of the site folder, e.g. "/entertainment-hub" or "" (site root).
    // Leave null to auto-detect.
    'base_url'       => $env('EH_BASE_URL', null),
    'max_body_bytes' => 40 * 1024 * 1024,
    'max_image_bytes' => 8 * 1024 * 1024,
    'upload_dir'     => dirname(__DIR__) . '/uploads',
];
