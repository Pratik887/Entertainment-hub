<?php
/**
 * Emergency password reset (command line ONLY).
 *
 *   php api/reset-password.php <username>
 *
 * Use this if the super admin forgets the password — there is no email reset.
 * Refuses to run from a web request.
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require __DIR__ . '/lib/init.php';

$username = $argv[1] ?? '';
if ($username === '') {
    fwrite(STDERR, "Usage: php api/reset-password.php <username>\n");
    exit(1);
}
$stmt = db()->prepare('SELECT id, username FROM users WHERE username_key = ?');
$stmt->execute([key_of($username)]);
$user = $stmt->fetch();
if (!$user) {
    fwrite(STDERR, "No such user: $username\n");
    exit(1);
}

fwrite(STDOUT, "New password for {$user['username']} (8-72 characters, input is visible): ");
$password = trim((string) fgets(STDIN));
try {
    $password = clean_password($password, 'The password');
} catch (ApiError $e) {
    fwrite(STDERR, $e->getMessage() . "\n");
    exit(1);
}
db()->prepare('UPDATE users SET password_hash = ?, active = 1 WHERE id = ?')->execute([hash_pw($password), (int) $user['id']]);
rate_clear('login_ip', '127.0.0.1');
log_activity('auth', $user['username'], 'Password reset from command line');
fwrite(STDOUT, "Done. All existing sessions for this account are now signed out.\n");
