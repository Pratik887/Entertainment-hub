<?php
/**
 * Loaded by the PUBLIC website pages. Exposes only publishable content
 * (no users, no analytics, no settings) as window.__EH_PUBLIC.
 */
declare(strict_types=1);

require __DIR__ . '/lib/init.php';
init_runtime();

header('Content-Type: application/javascript; charset=utf-8');

$data = [];
try {
    $data = load_content(PUBLIC_SECTIONS);
} catch (Throwable $e) {
    error_log('[entertainment-hub] ' . $e);
}

$body = 'window.__EH_PUBLIC = ' .
    json_encode((object) $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_INVALID_UTF8_SUBSTITUTE) . ';';

// Cheap revalidation: browsers re-check every time but only re-download when content changed.
$etag = '"' . md5($body) . '"';
header('Cache-Control: no-cache');
header('ETag: ' . $etag);
if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) {
    http_response_code(304);
    exit;
}
echo $body;
