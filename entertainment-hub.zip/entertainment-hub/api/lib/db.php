<?php
/**
 * PDO connection + schema (auto-created on first use).
 * Works with SQLite (default) and MySQL/MariaDB.
 */
declare(strict_types=1);

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = (string) cfg('db_dsn');
    if (str_starts_with($dsn, 'sqlite:')) {
        $file = substr($dsn, 7);
        $dir  = dirname($file);
        if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) {
            throw new RuntimeException('Cannot create database directory.');
        }
    }

    $pdo = new PDO($dsn, (string) cfg('db_user'), (string) cfg('db_pass'), [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);

    if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') {
        $pdo->exec('PRAGMA foreign_keys = ON');
        $pdo->exec('PRAGMA busy_timeout = 5000');
        $pdo->exec('PRAGMA journal_mode = WAL');
    }

    migrate($pdo);
    return $pdo;
}

function db_driver(): string
{
    return db()->getAttribute(PDO::ATTR_DRIVER_NAME);
}

function migrate(PDO $pdo): void
{
    $mysql = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql';
    $pk    = $mysql ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
    $long  = $mysql ? 'MEDIUMTEXT' : 'TEXT';
    $tail  = $mysql ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4' : '';

    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id $pk,
        username VARCHAR(24) NOT NULL,
        username_key VARCHAR(24) NOT NULL UNIQUE,
        email VARCHAR(190) NOT NULL,
        email_key VARCHAR(190) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(16) NOT NULL DEFAULT 'subadmin',
        active INTEGER NOT NULL DEFAULT 1,
        profile_photo VARCHAR(255) NOT NULL DEFAULT '',
        created_at VARCHAR(24) NOT NULL,
        last_login_at VARCHAR(24) NULL
    )$tail");

    $pdo->exec("CREATE TABLE IF NOT EXISTS signup_requests (
        id VARCHAR(40) NOT NULL PRIMARY KEY,
        username VARCHAR(24) NOT NULL,
        username_key VARCHAR(24) NOT NULL UNIQUE,
        email VARCHAR(190) NOT NULL,
        email_key VARCHAR(190) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        profile_photo VARCHAR(255) NOT NULL DEFAULT '',
        requested_at VARCHAR(24) NOT NULL,
        ip VARCHAR(45) NOT NULL DEFAULT ''
    )$tail");

    $pdo->exec("CREATE TABLE IF NOT EXISTS content (
        name VARCHAR(40) NOT NULL PRIMARY KEY,
        value $long NOT NULL,
        updated_at VARCHAR(24) NOT NULL,
        updated_by VARCHAR(24) NOT NULL DEFAULT ''
    )$tail");

    $pdo->exec("CREATE TABLE IF NOT EXISTS activity_log (
        id $pk,
        kind VARCHAR(10) NOT NULL DEFAULT 'content',
        username VARCHAR(24) NOT NULL DEFAULT '',
        action VARCHAR(300) NOT NULL,
        created_at VARCHAR(24) NOT NULL
    )$tail");

    $pdo->exec("CREATE TABLE IF NOT EXISTS rate_limits (
        id $pk,
        bucket VARCHAR(20) NOT NULL,
        subject VARCHAR(120) NOT NULL,
        at INTEGER NOT NULL
    )$tail");
    // Index creation: IF NOT EXISTS is not supported for MySQL indexes, so ignore "already exists".
    try {
        $pdo->exec('CREATE INDEX idx_rate_limits ON rate_limits (bucket, subject, at)');
    } catch (PDOException $e) {
        // already exists
    }
}
