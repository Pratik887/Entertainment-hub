<?php
/**
 * Turns base64 "data:image/..." strings (what the admin forms produce) into real
 * files in /uploads, so the database only keeps a short URL.
 */
declare(strict_types=1);

function is_data_url(string $v): bool
{
    return strncmp($v, 'data:image/', 11) === 0;
}

/**
 * @param string $prefix  'p_' for profile photos, 'c_' for site content
 * @return string public URL path, e.g. /entertainment-hub/uploads/c_ab12....jpg
 */
function store_data_url(string $dataUrl, string $prefix, ?int $maxBytes = null): string
{
    $maxBytes ??= (int) cfg('max_image_bytes');
    $comma = strpos($dataUrl, ',');
    if ($comma === false || $comma > 64 || !str_contains(substr($dataUrl, 0, $comma), ';base64')) {
        throw new ApiError('Unsupported image format.', 422);
    }
    $bytes = base64_decode(substr($dataUrl, $comma + 1), true);
    if ($bytes === false || $bytes === '') {
        throw new ApiError('Image data is corrupted.', 422);
    }
    if (strlen($bytes) > $maxBytes) {
        throw new ApiError('Image is too large.', 413);
    }

    // Trust the file's real content, not the claimed MIME type.
    $info = @getimagesizefromstring($bytes);
    $types = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_GIF => 'gif', IMAGETYPE_WEBP => 'webp'];
    if ($info === false || !isset($types[$info[2]])) {
        throw new ApiError('Only JPG, PNG, GIF or WebP images are allowed.', 422);
    }
    if ($info[0] > 10000 || $info[1] > 10000) {
        throw new ApiError('Image dimensions are too large.', 422);
    }

    $dir = (string) cfg('upload_dir');
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        throw new RuntimeException('Cannot create uploads directory.');
    }
    $name = $prefix . substr(hash('sha256', $bytes), 0, 32) . '.' . $types[$info[2]];
    $path = $dir . '/' . $name;
    if (!is_file($path)) {
        $tmp = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';
        if (file_put_contents($tmp, $bytes) === false || !rename($tmp, $path)) {
            @unlink($tmp);
            throw new RuntimeException('Cannot save the uploaded image.');
        }
        @chmod($path, 0644);
    }
    return base_url() . '/uploads/' . $name;
}

/** Delete a profile photo file once nothing references it any more. */
function delete_profile_photo_if_unused(string $url): void
{
    $name = basename($url);
    if (!preg_match('/^p_[a-f0-9]{32}\.(jpg|png|gif|webp)$/', $name)) {
        return;
    }
    foreach (['users', 'signup_requests'] as $table) {
        $stmt = db()->prepare("SELECT COUNT(*) FROM $table WHERE profile_photo = ?");
        $stmt->execute([$url]);
        if ((int) $stmt->fetchColumn() > 0) {
            return;
        }
    }
    @unlink(cfg('upload_dir') . '/' . $name);
}
