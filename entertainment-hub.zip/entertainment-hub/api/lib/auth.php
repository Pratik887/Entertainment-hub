<?php
/**
 * Authentication, users and the activity log.
 */
declare(strict_types=1);

/* ------------------------------------------------------------------ *
 * Validation
 * ------------------------------------------------------------------ */

function clean_username(mixed $v): string
{
    $v = is_string($v) ? trim($v) : '';
    if (!preg_match('/^[A-Za-z0-9._-]{3,24}$/', $v)) {
        throw new ApiError('Use 3–24 characters for the username: letters, numbers, periods, underscores, or hyphens.', 422);
    }
    return $v;
}

function clean_email(mixed $v): string
{
    $v = is_string($v) ? trim($v) : '';
    if ($v === '' || strlen($v) > 190 || !filter_var($v, FILTER_VALIDATE_EMAIL)) {
        throw new ApiError('Enter a valid email address.', 422);
    }
    return $v;
}

function clean_password(mixed $v, string $label = 'The password'): string
{
    $v = is_string($v) ? $v : '';
    if (strlen($v) < 8) {
        throw new ApiError("$label must be at least 8 characters.", 422);
    }
    if (strlen($v) > 72) {
        throw new ApiError("$label can be at most 72 characters.", 422);
    }
    return $v;
}

function key_of(string $s): string
{
    return strtolower($s);
}

function pw_fingerprint(string $hash): string
{
    return substr(hash('sha256', $hash), 0, 20);
}

function hash_pw(string $password): string
{
    $algo = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
    return password_hash($password, $algo);
}

/** Returns 'username' | 'email' | null  — checks users AND pending requests. */
function identity_taken(string $username, string $email, ?int $exceptUserId = null, ?string $exceptRequestId = null): ?string
{
    $uk = key_of($username);
    $ek = key_of($email);

    $stmt = db()->prepare('SELECT id, username_key, email_key FROM users WHERE username_key = ? OR email_key = ?');
    $stmt->execute([$uk, $ek]);
    foreach ($stmt->fetchAll() as $row) {
        if ($exceptUserId !== null && (int) $row['id'] === $exceptUserId) {
            continue;
        }
        return $row['username_key'] === $uk ? 'username' : 'email';
    }

    $stmt = db()->prepare('SELECT id, username_key, email_key FROM signup_requests WHERE username_key = ? OR email_key = ?');
    $stmt->execute([$uk, $ek]);
    foreach ($stmt->fetchAll() as $row) {
        if ($exceptRequestId !== null && $row['id'] === $exceptRequestId) {
            continue;
        }
        return $row['username_key'] === $uk ? 'username' : 'email';
    }
    return null;
}

/* ------------------------------------------------------------------ *
 * Activity log
 * ------------------------------------------------------------------ */

function log_activity(string $kind, string $username, string $action): void
{
    $action = htmlspecialchars(mb_substr(trim($action), 0, 250), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    db()->prepare('INSERT INTO activity_log (kind, username, action, created_at) VALUES (?, ?, ?, ?)')
        ->execute([$kind, $username, $action, now_iso()]);
    if (random_int(1, 100) === 1) {   // keep the table small
        $keep = db()->query('SELECT id FROM activity_log ORDER BY id DESC LIMIT 1 OFFSET 2000')->fetchColumn();
        if ($keep !== false) {
            db()->prepare('DELETE FROM activity_log WHERE id <= ?')->execute([$keep]);
        }
    }
}

/* ------------------------------------------------------------------ *
 * Users
 * ------------------------------------------------------------------ */

function public_user(array $row): array
{
    return [
        'id'           => (int) $row['id'],
        'username'     => $row['username'],
        'email'        => $row['email'],
        'role'         => $row['role'],
        'active'       => (int) $row['active'] === 1,
        'profilePhoto' => $row['profile_photo'],
        'createdAt'    => $row['created_at'],
        'lastLoginAt'  => $row['last_login_at'],
    ];
}

function needs_setup(): bool
{
    return (int) db()->query("SELECT COUNT(*) FROM users WHERE role = 'superadmin'")->fetchColumn() === 0;
}

function current_user(): ?array
{
    static $cache = false;
    if ($cache !== false) {
        return $cache;
    }
    $uid = $_SESSION['uid'] ?? null;
    if (!$uid) {
        return $cache = null;
    }
    $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([(int) $uid]);
    $row = $stmt->fetch();
    // Re-checked on EVERY request: disabling/removing an account, or changing its
    // password, kicks old sessions out immediately.
    if (!$row || (int) $row['active'] !== 1
        || !hash_equals(pw_fingerprint($row['password_hash']), (string) ($_SESSION['pwf'] ?? ''))) {
        destroy_session();
        start_session();
        return $cache = null;
    }
    return $cache = $row;
}

function require_login(): array
{
    $user = current_user();
    if (!$user) {
        throw new ApiError('Please sign in to continue.', 401);
    }
    return $user;
}

function require_super(): array
{
    $user = require_login();
    if ($user['role'] !== 'superadmin') {
        throw new ApiError('Only the super admin can do this.', 403);
    }
    return $user;
}

function establish_session(array $user): void
{
    session_regenerate_id(true);
    $_SESSION['uid']  = (int) $user['id'];
    $_SESSION['born'] = time();
    $_SESSION['last'] = time();
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    $_SESSION['pwf']  = pw_fingerprint($user['password_hash']);
    db()->prepare('UPDATE users SET last_login_at = ? WHERE id = ?')->execute([now_iso(), (int) $user['id']]);
}

function attempt_login(string $username, string $password): array
{
    $ip  = client_ip();
    $uk  = key_of(mb_substr($username, 0, 24));
    $max = (int) cfg('login_max_attempts');
    $win = (int) cfg('login_window');

    if (rate_count('login', $ip . '|' . $uk, $win) >= $max || rate_count('login_ip', $ip, $win) >= $max * 6) {
        throw new ApiError('Too many failed attempts. Please wait 15 minutes and try again.', 429);
    }

    $stmt = db()->prepare('SELECT * FROM users WHERE username_key = ?');
    $stmt->execute([$uk]);
    $user = $stmt->fetch();

    // Always run a hash verification so response time doesn't reveal whether the username exists.
    $hash = $user ? $user['password_hash'] : hash_pw('timing-equaliser');
    $ok   = password_verify($password, $hash) && $user && (int) $user['active'] === 1;

    if (!$ok) {
        rate_hit('login', $ip . '|' . $uk);
        rate_hit('login_ip', $ip);
        throw new ApiError('Incorrect username or password, or this account is inactive.', 401);
    }

    rate_clear('login', $ip . '|' . $uk);
    if (password_needs_rehash($user['password_hash'], defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT)) {
        db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([hash_pw($password), (int) $user['id']]);
    }
    establish_session($user);
    log_activity('auth', $user['username'], 'Login');

    $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([(int) $user['id']]);
    return $stmt->fetch();
}

function insert_user(string $username, string $email, string $passwordHash, string $role, string $photo): int
{
    db()->prepare('INSERT INTO users (username, username_key, email, email_key, password_hash, role, active, profile_photo, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)')
        ->execute([$username, key_of($username), $email, key_of($email), $passwordHash, $role, $photo, now_iso()]);
    return (int) db()->lastInsertId();
}

/** Accepts '' (none), an existing /uploads URL, or a data URL (stored as a file). */
function resolve_profile_photo(mixed $value, string $current = ''): string
{
    if (!is_string($value) || $value === '') {
        return '';
    }
    if (is_data_url($value)) {
        return store_data_url($value, 'p_', 1024 * 1024);
    }
    return $value === $current ? $current : '';
}
