<?php
/**
 * Site content (teams, slides, blogs, gallery, ...) stored as validated JSON documents.
 * The admin front-end edits whole sections, so each section is one row.
 */
declare(strict_types=1);

const CONTENT_SECTIONS = [
    'teams'        => 'list',
    'galleryMedia' => 'gallery',
    'blogPosts'    => 'list',
    'slides'       => 'list',
    'social'       => 'social',
    'liveStream'   => 'live',
    'analytics'    => 'analytics',
];
/** Sections only the super admin may change. */
const SUPER_ONLY_SECTIONS = ['social'];
/** Sections that the public website may read. */
const PUBLIC_SECTIONS = ['teams', 'galleryMedia', 'blogPosts', 'slides', 'liveStream'];
/** JSON keys that hold an image. Data-URLs are turned into files; anything else must look like a safe URL. */
const IMAGE_KEYS = ['image', 'img', 'thumbnail', 'profilePhoto'];

function clean_image_value(string $v): string
{
    if ($v === '') {
        return '';
    }
    if (is_data_url($v)) {
        return store_data_url($v, 'c_');
    }
    if (preg_match('#^https?://[^\s"\'<>`\\\\]{1,1000}$#i', $v)) {
        return $v;
    }
    // site-relative path such as /entertainment-hub/uploads/x.jpg or assets/images/x.png (no ":" => no javascript: URLs)
    if (preg_match('#^/?[A-Za-z0-9_][A-Za-z0-9_./-]{0,300}$#', $v) && !str_contains($v, '..')) {
        return $v;
    }
    throw new ApiError('One of the images has an invalid URL.', 422);
}

function walk_content(mixed $value, int $depth = 0, ?string $key = null): mixed
{
    if ($depth > 6) {
        throw new ApiError('Content is nested too deeply.', 422);
    }
    if (is_array($value)) {
        if (count($value) > 5000) {
            throw new ApiError('Too many items in one list.', 422);
        }
        $out = [];
        foreach ($value as $k => $v) {
            $out[$k] = walk_content($v, $depth + 1, is_string($k) ? $k : $key);
        }
        return $out;
    }
    if (is_string($value)) {
        if ($key !== null && in_array($key, IMAGE_KEYS, true)) {
            return clean_image_value($value);
        }
        if (strlen($value) > 20000) {
            throw new ApiError('A text field is too long.', 422);
        }
        return $value;
    }
    if (is_int($value) || is_float($value) || is_bool($value) || $value === null) {
        return $value;
    }
    throw new ApiError('Unsupported value in content.', 422);
}

function as_list(mixed $v, string $name): array
{
    if (!is_array($v) || ($v !== [] && !array_is_list($v))) {
        throw new ApiError("Section '$name' must be a list.", 422);
    }
    foreach ($v as $item) {
        if (!is_array($item)) {
            throw new ApiError("Section '$name' contains an invalid item.", 422);
        }
    }
    return $v;
}

function normalize_section(string $name, mixed $value): mixed
{
    $type = CONTENT_SECTIONS[$name];
    switch ($type) {
        case 'list':
            $value = as_list($value, $name);
            break;
        case 'gallery':
            if (!is_array($value)) {
                throw new ApiError("Section '$name' is invalid.", 422);
            }
            $value = [
                'photos' => as_list($value['photos'] ?? [], 'photos'),
                'videos' => as_list($value['videos'] ?? [], 'videos'),
                'shorts' => as_list($value['shorts'] ?? [], 'shorts'),
            ];
            break;
        case 'social':
            if (!is_array($value)) {
                throw new ApiError("Section '$name' is invalid.", 422);
            }
            $clean = [];
            foreach (['instagramId', 'facebookId', 'youtubeChannelId'] as $k) {
                $s = isset($value[$k]) && is_string($value[$k]) ? trim($value[$k]) : '';
                $clean[$k] = mb_substr($s, 0, 100);
            }
            $value = $clean;
            break;
        case 'live':
            if ($value !== null && !is_array($value)) {
                throw new ApiError("Section '$name' is invalid.", 422);
            }
            break;
        case 'analytics':
            if (!is_array($value) || !is_array($value['visitors'] ?? null)) {
                throw new ApiError("Section '$name' is invalid.", 422);
            }
            break;
    }
    return walk_content($value);
}

/** @return array<string,mixed> normalised values, as stored */
function save_sections(array $sections, array $user): array
{
    if (!$sections) {
        throw new ApiError('Nothing to save.', 422);
    }
    $prepared = [];
    foreach ($sections as $name => $value) {
        if (!is_string($name) || !isset(CONTENT_SECTIONS[$name])) {
            throw new ApiError('Unknown content section.', 422);
        }
        if (in_array($name, SUPER_ONLY_SECTIONS, true) && $user['role'] !== 'superadmin') {
            throw new ApiError('Only the super admin can change this setting.', 403);
        }
        $prepared[$name] = normalize_section($name, $value);
    }

    $pdo = db();
    $pdo->beginTransaction();
    try {
        foreach ($prepared as $name => $value) {
            $json = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
            if (strlen($json) > 25 * 1024 * 1024) {
                throw new ApiError("Section '$name' is too large.", 413);
            }
            $upd = $pdo->prepare('UPDATE content SET value = ?, updated_at = ?, updated_by = ? WHERE name = ?');
            $upd->execute([$json, now_iso(), $user['username'], $name]);
            if ($upd->rowCount() === 0) {
                try {
                    $pdo->prepare('INSERT INTO content (name, value, updated_at, updated_by) VALUES (?, ?, ?, ?)')
                        ->execute([$name, $json, now_iso(), $user['username']]);
                } catch (PDOException $e) {
                    // someone else inserted it a moment ago: update instead
                    $pdo->prepare('UPDATE content SET value = ?, updated_at = ?, updated_by = ? WHERE name = ?')
                        ->execute([$json, now_iso(), $user['username'], $name]);
                }
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
    return $prepared;
}

function load_content(?array $only = null): array
{
    $out = [];
    foreach (db()->query('SELECT name, value FROM content')->fetchAll() as $row) {
        if (!isset(CONTENT_SECTIONS[$row['name']])) {
            continue;
        }
        if ($only !== null && !in_array($row['name'], $only, true)) {
            continue;
        }
        $out[$row['name']] = json_decode($row['value'], true);
    }
    return $out;
}

function build_state(): array
{
    $activity = [];
    $auth     = [];
    $rows = db()->query('SELECT kind, username, action, created_at FROM activity_log ORDER BY id DESC LIMIT 50')->fetchAll();
    foreach ($rows as $r) {
        $text = $r['kind'] === 'auth'
            ? $r['action'] . ' by ' . $r['username']
            : $r['action'] . ($r['username'] !== '' ? ' (by ' . $r['username'] . ')' : '');
        $activity[] = ['time' => $r['created_at'], 'action' => $text];
    }
    $rows = db()->query("SELECT username, action, created_at FROM activity_log WHERE kind = 'auth' ORDER BY id DESC LIMIT 50")->fetchAll();
    foreach ($rows as $r) {
        $auth[] = ['username' => $r['username'], 'action' => $r['action'], 'timestamp' => $r['created_at']];
    }
    return [
        'content'     => (object) load_content(),
        'activityLog' => $activity,
        'authEvents'  => $auth,
    ];
}
