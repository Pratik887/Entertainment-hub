<?php
/**
 * Common bootstrap: config, error handling, secure session.
 */
declare(strict_types=1);

const EH_ROOT = __DIR__ . '/..';

function cfg(string $key)
{
    static $config = null;
    if ($config === null) {
        $config = require EH_ROOT . '/config.php';
    }
    return $config[$key] ?? null;
}

function is_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    if (cfg('trust_proxy_headers')
        && strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https') {
        return true;
    }
    return false;
}

function client_ip(): string
{
    if (cfg('trust_proxy_headers') && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $first = trim(explode(',', (string) $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
        if (filter_var($first, FILTER_VALIDATE_IP)) {
            return $first;
        }
    }
    return (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

/** URL prefix of the site folder, e.g. "/entertainment-hub" (no trailing slash). */
function base_url(): string
{
    $configured = cfg('base_url');
    if (is_string($configured)) {
        return rtrim($configured, '/');
    }
    $script = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? '/api/index.php'));
    $dir = dirname(dirname($script));          // strip "/api/<file>.php"
    return $dir === '/' || $dir === '.' ? '' : rtrim($dir, '/');
}

function now_iso(): string
{
    return gmdate('Y-m-d\TH:i:s\Z');
}

function init_runtime(): void
{
    error_reporting(E_ALL);
    ini_set('display_errors', '0');     // never leak stack traces to visitors
    ini_set('log_errors', '1');
    date_default_timezone_set('UTC');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header('X-Frame-Options: DENY');
}

function start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_trans_sid', '0');
    session_name((string) cfg('session_name'));
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();

    $now = time();
    if (isset($_SESSION['uid'])) {
        $idle     = $now - (int) ($_SESSION['last'] ?? 0);
        $lifetime = $now - (int) ($_SESSION['born'] ?? 0);
        if ($idle > (int) cfg('session_idle') || $lifetime > (int) cfg('session_absolute')) {
            destroy_session();
            session_start();
        }
    }
    if (!isset($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    if (isset($_SESSION['uid'])) {
        $_SESSION['last'] = $now;
    }
}

function destroy_session(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires'  => time() - 42000,
            'path'     => $p['path'],
            'secure'   => $p['secure'],
            'httponly' => $p['httponly'],
            'samesite' => $p['samesite'] ?? 'Lax',
        ]);
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/http.php';
require_once __DIR__ . '/uploads.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/content.php';
