<?php
/**
 * HTTP helpers: JSON in/out, CSRF, rate limiting.
 */
declare(strict_types=1);

class ApiError extends Exception
{
    public int $status;
    public function __construct(string $message, int $status = 400)
    {
        parent::__construct($message);
        $this->status = $status;
    }
}

function send_json($data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function read_json_body(): array
{
    $length = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > (int) cfg('max_body_bytes')) {
        throw new ApiError('Request is too large.', 413);
    }
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') {
        return [];
    }
    if (strlen($raw) > (int) cfg('max_body_bytes')) {
        throw new ApiError('Request is too large.', 413);
    }
    $data = json_decode($raw, true, 64);
    if (!is_array($data)) {
        throw new ApiError('Invalid JSON body.', 400);
    }
    return $data;
}

/** Same-origin + token check. Call for every state-changing request. */
function require_csrf(): void
{
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '') {
        $originHost = parse_url($origin, PHP_URL_HOST);
        $originPort = parse_url($origin, PHP_URL_PORT);
        $host = (string) ($_SERVER['HTTP_HOST'] ?? '');
        $originAuthority = $originHost . ($originPort ? ':' . $originPort : '');
        if (!$originHost || strcasecmp($originAuthority, $host) !== 0) {
            throw new ApiError('Cross-site request blocked.', 403);
        }
    }
    $sent = (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    $real = (string) ($_SESSION['csrf'] ?? '');
    if ($sent === '' || $real === '' || !hash_equals($real, $sent)) {
        throw new ApiError('Security token missing or expired. Reload the page and try again.', 403);
    }
}

/* ---------- Rate limiting (stored in DB so it survives across requests) ---------- */

function rate_count(string $bucket, string $subject, int $window): int
{
    $stmt = db()->prepare('SELECT COUNT(*) FROM rate_limits WHERE bucket = ? AND subject = ? AND at > ?');
    $stmt->execute([$bucket, $subject, time() - $window]);
    return (int) $stmt->fetchColumn();
}

function rate_hit(string $bucket, string $subject): void
{
    db()->prepare('INSERT INTO rate_limits (bucket, subject, at) VALUES (?, ?, ?)')
        ->execute([$bucket, $subject, time()]);
    if (random_int(1, 50) === 1) {   // opportunistic cleanup
        db()->prepare('DELETE FROM rate_limits WHERE at < ?')->execute([time() - 86400]);
    }
}

function rate_clear(string $bucket, string $subject): void
{
    db()->prepare('DELETE FROM rate_limits WHERE bucket = ? AND subject = ?')->execute([$bucket, $subject]);
}
