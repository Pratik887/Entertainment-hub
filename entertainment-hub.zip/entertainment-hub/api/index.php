<?php
/**
 * JSON API front controller:  api/index.php?action=<name>
 *
 *  GET   session, state, admin_users
 *  POST  setup, login, logout, signup, save, log, account_update, password_change,
 *        request_approve, request_deny, subadmin_create, subadmin_update,
 *        subadmin_toggle, subadmin_delete, reset_content
 */
declare(strict_types=1);

require __DIR__ . '/lib/init.php';
init_runtime();

function session_payload(): array
{
    $user = current_user();
    return [
        'authenticated' => $user !== null,
        'user'          => $user ? public_user($user) : null,
        'csrf'          => $_SESSION['csrf'] ?? '',
        'needsSetup'    => needs_setup(),
        'setupKeyRequired' => (string) cfg('setup_key') !== '',
        'allowSignup'   => (bool) cfg('allow_signup_requests'),
    ];
}

function body_string(array $b, string $k, int $max = 1000): string
{
    $v = $b[$k] ?? '';
    return is_string($v) ? mb_substr($v, 0, $max) : '';
}

function find_subadmin(array $b): array
{
    $stmt = db()->prepare("SELECT * FROM users WHERE id = ? AND role = 'subadmin'");
    $stmt->execute([(int) ($b['id'] ?? 0)]);
    $row = $stmt->fetch();
    if (!$row) {
        throw new ApiError('That sub-admin account could not be found.', 404);
    }
    return $row;
}

$routes = [
    /* ---------------- read-only ---------------- */
    'session' => ['GET', fn() => session_payload()],

    'state' => ['GET', function () {
        require_login();
        return build_state();
    }],

    'admin_users' => ['GET', function () {
        require_super();
        $requests = [];
        foreach (db()->query('SELECT * FROM signup_requests ORDER BY requested_at ASC')->fetchAll() as $r) {
            $requests[] = [
                'id' => $r['id'], 'username' => $r['username'], 'email' => $r['email'],
                'profilePhoto' => $r['profile_photo'], 'requestedAt' => $r['requested_at'],
            ];
        }
        $admins = [];
        foreach (db()->query("SELECT * FROM users WHERE role = 'subadmin' ORDER BY id ASC")->fetchAll() as $u) {
            $admins[] = public_user($u);
        }
        return ['requests' => $requests, 'subAdmins' => $admins];
    }],

    /* ---------------- authentication ---------------- */
    'setup' => ['POST', function () {
        $b  = read_json_body();
        $ip = client_ip();
        if (!needs_setup()) {
            throw new ApiError('Setup has already been completed.', 409);
        }
        if (rate_count('setup', $ip, 3600) >= 10) {
            throw new ApiError('Too many attempts. Try again later.', 429);
        }
        rate_hit('setup', $ip);

        $key = (string) cfg('setup_key');
        if ($key !== '' && !hash_equals($key, body_string($b, 'setupKey', 200))) {
            throw new ApiError('The setup key is incorrect.', 403);
        }
        $username = clean_username($b['username'] ?? '');
        $email    = clean_email($b['email'] ?? '');
        $password = clean_password($b['password'] ?? '');

        $pdo = db();
        $pdo->beginTransaction();
        try {
            $id = insert_user($username, $email, hash_pw($password), 'superadmin', '');
            $count = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'superadmin'")->fetchColumn();
            if ($count > 1) {
                throw new ApiError('Setup has already been completed.', 409);
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
        $stmt->execute([$id]);
        $user = $stmt->fetch();
        establish_session($user);
        log_activity('auth', $username, 'Super admin account created');
        return ['user' => public_user($user), 'csrf' => $_SESSION['csrf']];
    }],

    'login' => ['POST', function () {
        $b = read_json_body();
        $username = body_string($b, 'username', 64);
        $password = body_string($b, 'password', 1024);
        if ($username === '' || $password === '') {
            throw new ApiError('Enter your username and password.', 422);
        }
        $user = attempt_login(trim($username), $password);
        return ['user' => public_user($user), 'csrf' => $_SESSION['csrf']];
    }],

    'logout' => ['POST', function () {
        $user = current_user();
        if ($user) {
            log_activity('auth', $user['username'], 'Logout');
        }
        destroy_session();
        start_session();
        return ['ok' => true, 'csrf' => $_SESSION['csrf']];
    }],

    'signup' => ['POST', function () {
        if (!cfg('allow_signup_requests')) {
            throw new ApiError('Sub-admin requests are disabled.', 403);
        }
        if (needs_setup()) {
            throw new ApiError('The site is not set up yet.', 409);
        }
        $b  = read_json_body();
        $ip = client_ip();
        if (rate_count('signup', $ip, 3600) >= (int) cfg('signup_per_hour')) {
            throw new ApiError('Too many requests from this network. Try again later.', 429);
        }
        if ((int) db()->query('SELECT COUNT(*) FROM signup_requests')->fetchColumn() >= 200) {
            throw new ApiError('Not accepting new requests right now.', 503);
        }
        $username = clean_username($b['username'] ?? '');
        $email    = clean_email($b['email'] ?? '');
        $password = clean_password($b['password'] ?? '', 'The temporary password');
        rate_hit('signup', $ip);

        if (identity_taken($username, $email) !== null) {
            throw new ApiError('That username or email is already in use or awaiting review.', 409);
        }
        $photo = resolve_profile_photo($b['profilePhoto'] ?? '');
        $id = 'request-' . bin2hex(random_bytes(8));
        db()->prepare('INSERT INTO signup_requests (id, username, username_key, email, email_key, password_hash, profile_photo, requested_at, ip)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$id, $username, key_of($username), $email, key_of($email), hash_pw($password), $photo, now_iso(), $ip]);
        log_activity('auth', $username, 'Requested sub-admin access');
        return ['ok' => true];
    }],

    /* ---------------- content ---------------- */
    'save' => ['POST', function () {
        $user = require_login();
        $b = read_json_body();
        if (!isset($b['sections']) || !is_array($b['sections'])) {
            throw new ApiError('Nothing to save.', 422);
        }
        return ['content' => (object) save_sections($b['sections'], $user)];
    }],

    'log' => ['POST', function () {
        $user = require_login();
        $b = read_json_body();
        $action = trim(body_string($b, 'action', 250));
        if ($action === '') {
            throw new ApiError('Missing action.', 422);
        }
        log_activity('content', $user['username'], $action);
        return ['ok' => true];
    }],

    /* ---------------- own account ---------------- */
    'account_update' => ['POST', function () {
        $user = require_super();
        $b = read_json_body();
        $username = clean_username($b['username'] ?? '');
        $email    = clean_email($b['email'] ?? '');
        if (identity_taken($username, $email, (int) $user['id']) !== null) {
            throw new ApiError('That username or email is already in use.', 409);
        }
        db()->prepare('UPDATE users SET username = ?, username_key = ?, email = ?, email_key = ? WHERE id = ?')
            ->execute([$username, key_of($username), $email, key_of($email), (int) $user['id']]);
        log_activity('auth', $username, 'Updated account details');
        $stmt = db()->prepare('SELECT * FROM users WHERE id = ?');
        $stmt->execute([(int) $user['id']]);
        return ['user' => public_user($stmt->fetch())];
    }],

    'password_change' => ['POST', function () {
        $user = require_login();
        $b = read_json_body();
        $current = body_string($b, 'current', 1024);
        $new     = clean_password($b['new'] ?? '', 'The new password');
        $ip = client_ip();
        if (rate_count('pwchange', $user['id'] . '', 900) >= 5) {
            throw new ApiError('Too many attempts. Please wait a few minutes.', 429);
        }
        if (!password_verify($current, $user['password_hash'])) {
            rate_hit('pwchange', $user['id'] . '');
            throw new ApiError('Current password is incorrect.', 403);
        }
        $hash = hash_pw($new);
        db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([$hash, (int) $user['id']]);
        session_regenerate_id(true);
        $_SESSION['pwf'] = pw_fingerprint($hash);   // keeps THIS session alive, ends all others
        log_activity('auth', $user['username'], 'Changed account password');
        return ['ok' => true];
    }],

    /* ---------------- super admin: requests & sub-admins ---------------- */
    'request_approve' => ['POST', function () {
        $actor = require_super();
        $b = read_json_body();
        $stmt = db()->prepare('SELECT * FROM signup_requests WHERE id = ?');
        $stmt->execute([body_string($b, 'id', 60)]);
        $r = $stmt->fetch();
        if (!$r) {
            throw new ApiError('This access request was not found. Refresh the list and try again.', 404);
        }
        $stmt = db()->prepare('SELECT username_key, email_key FROM users WHERE username_key = ? OR email_key = ?');
        $stmt->execute([$r['username_key'], $r['email_key']]);
        if ($row = $stmt->fetch()) {
            throw new ApiError($row['username_key'] === $r['username_key']
                ? "Cannot approve {$r['username']}: that username is already in use."
                : "Cannot approve {$r['username']}: that email is already in use.", 409);
        }
        $pdo = db();
        $pdo->beginTransaction();
        try {
            insert_user($r['username'], $r['email'], $r['password_hash'], 'subadmin', $r['profile_photo']);
            $pdo->prepare('DELETE FROM signup_requests WHERE id = ?')->execute([$r['id']]);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
        log_activity('auth', $actor['username'], 'Approved sub-admin request from ' . $r['username']);
        return ['ok' => true, 'username' => $r['username']];
    }],

    'request_deny' => ['POST', function () {
        $actor = require_super();
        $b = read_json_body();
        $stmt = db()->prepare('SELECT * FROM signup_requests WHERE id = ?');
        $stmt->execute([body_string($b, 'id', 60)]);
        $r = $stmt->fetch();
        if (!$r) {
            throw new ApiError('This access request was not found. Refresh the list and try again.', 404);
        }
        db()->prepare('DELETE FROM signup_requests WHERE id = ?')->execute([$r['id']]);
        delete_profile_photo_if_unused($r['profile_photo']);
        log_activity('auth', $actor['username'], 'Declined sub-admin request from ' . $r['username']);
        return ['ok' => true, 'username' => $r['username']];
    }],

    'subadmin_create' => ['POST', function () {
        $actor = require_super();
        $b = read_json_body();
        $username = clean_username($b['username'] ?? '');
        $email    = clean_email($b['email'] ?? '');
        $password = clean_password($b['password'] ?? '', 'The temporary password');
        if (identity_taken($username, $email) !== null) {
            throw new ApiError('That username or email is already in use.', 409);
        }
        $photo = resolve_profile_photo($b['profilePhoto'] ?? '');
        insert_user($username, $email, hash_pw($password), 'subadmin', $photo);
        log_activity('auth', $actor['username'], 'Created sub-admin ' . $username);
        return ['ok' => true];
    }],

    'subadmin_update' => ['POST', function () {
        $actor = require_super();
        $b = read_json_body();
        $row = find_subadmin($b);
        $username = clean_username($b['username'] ?? '');
        $email    = clean_email($b['email'] ?? '');
        if (identity_taken($username, $email, (int) $row['id']) !== null) {
            throw new ApiError('That username or email is already in use.', 409);
        }
        $newPassword = body_string($b, 'password', 1024);
        $hash = $row['password_hash'];
        if ($newPassword !== '') {
            $hash = hash_pw(clean_password($newPassword, 'The new password'));
        }
        $photo = resolve_profile_photo($b['profilePhoto'] ?? '', $row['profile_photo']);
        db()->prepare('UPDATE users SET username = ?, username_key = ?, email = ?, email_key = ?, password_hash = ?, profile_photo = ? WHERE id = ?')
            ->execute([$username, key_of($username), $email, key_of($email), $hash, $photo, (int) $row['id']]);
        if ($photo !== $row['profile_photo']) {
            delete_profile_photo_if_unused($row['profile_photo']);
        }
        log_activity('auth', $actor['username'], 'Updated sub-admin ' . $username);
        return ['ok' => true, 'username' => $username];
    }],

    'subadmin_toggle' => ['POST', function () {
        $actor = require_super();
        $row = find_subadmin(read_json_body());
        $active = (int) $row['active'] === 1 ? 0 : 1;
        db()->prepare('UPDATE users SET active = ? WHERE id = ?')->execute([$active, (int) $row['id']]);
        log_activity('auth', $actor['username'], ($active ? 'Enabled' : 'Disabled') . ' sub-admin ' . $row['username']);
        return ['ok' => true, 'active' => $active === 1];
    }],

    'subadmin_delete' => ['POST', function () {
        $actor = require_super();
        $row = find_subadmin(read_json_body());
        db()->prepare('DELETE FROM users WHERE id = ?')->execute([(int) $row['id']]);
        delete_profile_photo_if_unused($row['profile_photo']);
        log_activity('auth', $actor['username'], 'Removed sub-admin ' . $row['username']);
        return ['ok' => true];
    }],

    'reset_content' => ['POST', function () {
        $actor = require_super();
        db()->exec('DELETE FROM content');
        db()->exec("DELETE FROM activity_log WHERE kind = 'content'");
        log_activity('auth', $actor['username'], 'Reset site content to defaults');
        return ['ok' => true];
    }],
];

try {
    start_session();
    $action = (string) ($_GET['action'] ?? '');
    if (!isset($routes[$action])) {
        throw new ApiError('Unknown action.', 404);
    }
    [$method, $handler] = $routes[$action];
    if ($_SERVER['REQUEST_METHOD'] !== $method) {
        header('Allow: ' . $method);
        throw new ApiError('Method not allowed.', 405);
    }
    if ($method === 'POST') {
        require_csrf();
    }
    send_json($handler());
} catch (ApiError $e) {
    send_json(['error' => $e->getMessage()], $e->status);
} catch (Throwable $e) {
    error_log('[entertainment-hub] ' . $e);
    send_json(['error' => 'Server error. Please try again.'], 500);
}
