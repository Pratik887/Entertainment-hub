/* =====================================================================
   ENTERTAINMENT HUB — SCRIPT.JS
   Table of Contents:
   1. Content Data
   2. Helpers
   3. Header: date, ticker, theme toggle, hamburger, search
   4. Hero Slider
   5. Trending / Movies / OTT / Celebrity / Video / Gallery render
   6. Latest News: filter, load more (pagination)
   7. Card interactions: like, bookmark, share
   8. Sidebar: popular tabs, categories, tags, instagram
   9. Live Updates
   10. Newsletter validation
   11. FAQ Accordion
   12. Reading progress + back to top
   13. Scroll reveal + counter animation
   14. Lightbox gallery
   15. Init
===================================================================== */

(() => {
  'use strict';

  /* ---------------------------------------------------------------
     1. CONTENT DATA
  ------------------------------------------------------------------ */
  const CATEGORIES = [
    'Movies', 'OTT', 'Celebrity', 'TV Shows', 'Music',
    'Trailers', 'Reviews', 'Lifestyle', 'Fashion', 'Awards'
  ];

  const AUTHORS = ['Ritu Sharma', 'Aman Verma', 'Priya Nair', 'Karan Mehta', 'Sneha Rao', 'Vikram Das'];

  function pick(arr, i) { return arr[i % arr.length]; }
  function seedImg(seed, w, h) { return `https://picsum.photos/seed/${seed}/${w}/${h}`; }
  function randViews() { return Math.floor(Math.random() * 900 + 20); }

  const NEWS_HEADLINES = [
    'Zeenat: Rise of the Phoenix wraps first schedule in Ladakh',
    'Streaming wars heat up as three platforms release originals same week',
    'Playback singer Meher Kapoor announces first world tour',
    'Veteran director Ashok Malhotra to receive lifetime achievement award',
    'Superstar couple spotted at Mumbai airport ahead of Maldives trip',
    'Regional cinema box office crosses ₹500 crore milestone this year',
    'New biopic on freedom fighter enters production this month',
    'Comic-Con India lineup announced with surprise celebrity panel',
    'Debut director\'s indie drama picked up for international distribution',
    'Popular sitcom renewed for fifth season after record viewership',
    'Music composer duo to score upcoming period drama',
    'Award-winning actress to make Broadway debut next spring',
    'Late-night talk show host confirms new season premiere date',
    'Animated feature breaks opening weekend records in three territories',
    'Fashion designer unveils red carpet collection ahead of awards night',
    'Cult classic film to get 25th anniversary theatrical re-release',
    'Reality dance competition finale draws highest ratings of the season',
    'Acclaimed novelist\'s bestseller confirmed for streaming adaptation',
    'Rock band reunites for one-night charity concert in Delhi',
    'Child actor from hit drama signs first lead role in feature film'
  ];

  const NEWS = NEWS_HEADLINES.map((title, i) => ({
    id: `news-${i}`,
    title,
    desc: 'A closer look at the story fans are talking about today, with details straight from our entertainment desk.',
    category: pick(CATEGORIES, i),
    author: pick(AUTHORS, i),
    date: `Jul ${((i % 22) + 1)}, 2026`,
    views: randViews(),
    img: seedImg('news' + i, 500, 320),
    trending: i < 15
  }));

  const MOVIES = Array.from({ length: 10 }, (_, i) => {
    const titles = ['Zeenat: Rise of the Phoenix', 'Monsoon Diaries', 'The Last Cipher', 'Dilli Nights', 'Aatma Ek Safar',
      'Fireflies of Kashmir', 'Rang Rasiya 2', 'Whispers in Wadi', 'Chase Card', 'Blue Hour Bombay'];
    return {
      id: `movie-${i}`,
      title: titles[i],
      status: i % 3 === 0 ? 'upcoming' : 'latest',
      rating: (7 + (i % 3) * 0.6).toFixed(1),
      boxoffice: Math.floor(30 + i * 12),
      genre: pick(['Action', 'Drama', 'Thriller', 'Romance', 'Comedy'], i),
      date: `Aug ${((i % 28) + 1)}, 2026`,
      img: seedImg('movie' + i, 480, 300)
    };
  });

  const OTT_PLATFORMS = ['Netflix', 'Prime Video', 'Disney+', 'JioHotstar', 'Sony LIV', 'ZEE5', 'Apple TV+'];
  const OTT = Array.from({ length: 10 }, (_, i) => ({
    id: `ott-${i}`,
    title: ['Crimson Alley', 'Bandra Blues', 'The Boardroom', 'Ghost Circuit', 'Made in Colaba',
      'Sirens of Sindhudurg', 'Kaal Chakra', 'Second Innings', 'Neon Bazaar', 'The Understudy'][i],
    platform: pick(OTT_PLATFORMS, i),
    tag: pick(['New Release', 'Trending Show', 'Upcoming Release'], i),
    seasons: (i % 4) + 1,
    img: seedImg('ott' + i, 480, 300)
  }));

  const CELEBS = Array.from({ length: 10 }, (_, i) => ({
    id: `celeb-${i}`,
    name: ['Ananya Kapoor', 'Rehan Sheikh', 'Ishita Malhotra', 'Dev Ahluwalia', 'Meher Kapoor',
      'Arjun Bakshi', 'Kavya Iyer', 'Farhan Qureshi', 'Simran Chadha', 'Rohan Oberoi'][i],
    role: pick(['Actor', 'Actress', 'Singer', 'Director', 'Producer'], i),
    tag: pick(['Interview', 'Fashion', 'Awards', 'Birthday', 'Relationship'], i),
    img: seedImg('celeb' + i, 400, 400)
  }));

  const VIDEOS = Array.from({ length: 8 }, (_, i) => ({
    id: `video-${i}`,
    title: ['Zeenat — Official Trailer', 'Monsoon Diaries — Teaser', 'Meher Kapoor — Studio Session',
      'Chase Card — Behind the Scenes', 'The Boardroom — Season 2 Trailer', 'Awards Night — Best Moments',
      'Rang Rasiya 2 — Title Track', 'Comic-Con India — Panel Highlights'][i],
    duration: `${(i % 3) + 1}:${(20 + i * 7) % 60}`.replace(/(\d):(\d)$/, '$1:0$2'),
    img: seedImg('video' + i, 480, 280)
  }));

  const GALLERY = Array.from({ length: 20 }, (_, i) => ({
    id: `gal-${i}`,
    img: seedImg('gallery' + i, 400, 300 + (i % 4) * 60),
    caption: `Awards night moment #${i + 1}`
  }));

  function getAdminGalleryMedia() {
    try {
      const saved = window.__EH_PUBLIC?.galleryMedia || {};
      return {
        photos: Array.isArray(saved.photos) ? saved.photos : [],
        videos: Array.isArray(saved.videos) ? saved.videos : [],
        shorts: Array.isArray(saved.shorts) ? saved.shorts : []
      };
    } catch (error) {
      return { photos: [], videos: [], shorts: [] };
    }
  }

  function getGalleryPhotos() {
    const adminPhotos = getAdminGalleryMedia().photos.map(photo => ({
      id: photo.id,
      img: photo.image,
      caption: photo.title
    }));
    return [...adminPhotos, ...GALLERY];
  }

  const LIVE_UPDATES = [
    { time: '11:42 AM', text: 'Trailer for "Zeenat: Rise of the Phoenix" crosses 10M views within 6 hours.' },
    { time: '11:10 AM', text: 'Ticket pre-sales open for the 25th anniversary re-release of a cult classic.' },
    { time: '10:35 AM', text: 'Award nominations shortlist to be announced later today.' },
    { time: '09:58 AM', text: 'Streaming platform confirms renewal of a fan-favourite series.' },
    { time: '09:20 AM', text: 'Red carpet arrivals begin for tonight\'s premiere in Mumbai.' }
  ];

  // Real YouTube channel IDs — the /embed/live_stream?channel= endpoint automatically
  // plays whatever that channel currently has live, so it never goes stale.
  const LIVE_CHANNELS = [
    { name: 'NDTV 24x7', id: 'UCZFMm1mMw0F81Z37aaEzTUA' },
    { name: 'Aaj Tak', id: 'UCt4t-jeY85JegMlZ-E5UWtA' },
    { name: 'India Today', id: 'UCYPvAwZP8pZhSMW8qs7cVCw' }
  ];

  const TICKER_ITEMS = [
    'Zeenat: Rise of the Phoenix trailer crosses 10M views in a day',
    'Award nominations shortlist expected this evening',
    'Fan-favourite series renewed for a new season',
    'Box office collections cross ₹500 crore for regional cinema this year',
    'Music composer duo confirmed for upcoming period drama'
  ];

  /* --- Sample public YouTube video IDs used across popups/modals --- */
  const SAMPLE_YT_IDS = ['dQw4w9WgXcQ', 'jNQXAC9IVRw', 'ScMzIvxBSi4', '9bZkp7q19f0', 'L_jWHffIx5E', 'M7lc1UVf-VE', 'tgbNymZ7vqY', 'kXYiU_JCYtU'];

  /* --- Clients / Partners --- */
  const CLIENTS = Array.from({ length: 10 }, (_, i) => ({
    id: `client-${i}`,
    name: ['Skyline Studios', 'Vantage Media', 'Crimson Films', 'Northgate OTT', 'Harbor Music', 'Zenith Productions',
      'Bluewave Network', 'Starlight Talent', 'Prime Broadcast', 'Aurora Pictures'][i],
    img: seedImg('client' + i, 300, 160)
  }));

  /* --- Government & Entertainment Events --- */
  const GOV_EVENTS = Array.from({ length: 6 }, (_, i) => ({
    id: `gov-event-${i}`,
    name: ['National Film Heritage Summit', 'Ministry of Culture Media Meet', 'State Tourism & Film Conclave',
      'Digital Media Policy Forum', 'National Youth Arts Festival', 'Public Broadcasting Council Session'][i],
    date: `Sep ${((i % 28) + 1)}, 2026`,
    venue: pick(['Vigyan Bhawan, New Delhi', 'Raj Bhavan, Mumbai', 'Convention Centre, Bengaluru', 'Pragati Maidan, New Delhi'], i),
    desc: 'An official gathering bringing together policymakers, industry leaders and media professionals to discuss the road ahead.',
    img: seedImg('govevent' + i, 480, 300)
  }));

  const ENT_EVENTS = Array.from({ length: 6 }, (_, i) => ({
    id: `ent-event-${i}`,
    name: ['RedCrab Entertainment Awards Night', 'Star-Studded Movie Premiere', 'Music Fest Live in Concert',
      'OTT Creators Meetup', 'Fashion & Film Gala', 'Comic-Con India Panel'][i],
    date: `Oct ${((i % 28) + 1)}, 2026`,
    venue: pick(['Jio World Convention Centre, Mumbai', 'NSCI Dome, Mumbai', 'Indira Gandhi Indoor Stadium, Delhi', 'Phoenix Marketcity, Bengaluru'], i),
    desc: 'A star-studded evening celebrating the very best in entertainment, music and cinema this season.',
    img: seedImg('evevent' + i, 480, 300)
  }));

  /* --- Recent Blogs (replaces Popular Articles widget) --- */
  const BLOGS = Array.from({ length: 6 }, (_, i) => ({
    id: `blog-${i}`,
    title: ['5 Reasons Zeenat: Rise of the Phoenix Is 2026\'s Biggest Bet', 'Inside the Making of a Monsoon Blockbuster',
      'How OTT Platforms Are Reshaping Regional Cinema', 'Backstage at Awards Night: What You Didn\'t See on TV',
      'The Rise of Vertical Video in Entertainment News', 'Meet the Composers Behind This Year\'s Biggest Soundtracks'][i],
    img: seedImg('blog' + i, 200, 200),
    date: `Jul ${((i % 22) + 1)}, 2026`
  }));

  /* --- Recent Shorts (20-second vertical videos) --- */
  const SHORTS = Array.from({ length: 8 }, (_, i) => ({
    id: `short-${i}`,
    caption: `Short #${i + 1}`,
    duration: '0:20',
    img: seedImg('short' + i, 300, 530),
    yt: pick(SAMPLE_YT_IDS, i)
  }));

  /* --- Official YouTube Videos --- */
  const OFFICIAL_YT = Array.from({ length: 8 }, (_, i) => ({
    id: `offyt-${i}`,
    title: ['RedCrab Entertainment — Channel Trailer', 'Awards Night 2026 — Full Highlights', 'Exclusive: On Set With The Cast',
      'Top 10 Moments From This Month', 'Live Red Carpet Coverage — Recap', 'Behind the Scenes: Studio Diaries',
      'Fan Q&A — Celebrity Special', 'This Week in Entertainment — Wrap Up'][i],
    duration: `${(i % 4) + 2}:${(10 + i * 6) % 60}`.replace(/(\d):(\d)$/, '$1:0$2'),
    img: seedImg('offyt' + i, 480, 280),
    yt: pick(SAMPLE_YT_IDS, i)
  }));

  /* --- Awards page data --- */
  const AWARDS = Array.from({ length: 9 }, (_, i) => ({
    id: `award-${i}`,
    title: ['Best Picture of the Year', 'Best Lead Performance', 'Best Original Soundtrack', 'Best Director',
      'Outstanding OTT Original', 'Lifetime Achievement Honour', 'Best Newcomer', 'Best Regional Film', 'Best Documentary'][i],
    org: pick(['RedCrab Entertainment Awards', 'National Film Critics Circle', 'Global Streaming Awards', 'Cinema Excellence Guild'], i),
    date: `Nov ${((i % 28) + 1)}, 2026`,
    desc: 'Recognising outstanding creative achievement and excellence across film, television and streaming this year.',
    img: seedImg('award' + i, 480, 300)
  }));

  /* --- Interviews page data --- */
  const INTERVIEWS = Array.from({ length: 9 }, (_, i) => ({
    id: `interview-${i}`,
    title: ['In Conversation With the Cast of Zeenat', 'Director\'s Cut: Building a Blockbuster', 'The Music Behind the Magic',
      'Candid Chat With a Rising Star', 'Life on Set: Stories From the Crew', 'From Screenplay to Screen: Writer\'s Roundtable',
      'A Producer\'s Perspective on OTT', 'Award Season Diaries: Winners Speak', 'Comic-Con Special: Fan Favourites'][i],
    desc: 'An in-depth conversation covering craft, inspiration, and the stories behind the scenes.',
    img: seedImg('interview' + i, 480, 300),
    yt: pick(SAMPLE_YT_IDS, i)
  }));

  /* ---------------------------------------------------------------
     2. HELPERS
  ------------------------------------------------------------------ */
  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

  function showToast(message, icon = '✓') {
    const container = $('#toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span>${icon}</span><span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('hide');
      setTimeout(() => toast.remove(), 320);
    }, 2400);
  }

  function cardActionsHTML(id) {
    return `
      <div class="card-actions">
        <button class="like-btn" data-id="${id}" aria-label="Like this article">❤ <span class="like-count">0</span></button>
        <button class="bookmark-btn" data-id="${id}" aria-label="Bookmark this article">🔖</button>
        <button class="share-btn" data-id="${id}" aria-label="Share this article">↗</button>
      </div>`;
  }

  /* ---------------------------------------------------------------
     3. HEADER
  ------------------------------------------------------------------ */
  function initDate() {
    const el = $('#currentDate');
    if (!el) return;
    el.textContent = new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  }

  function initTicker() {
    const track = $('#tickerTrack');
    if (!track) return;
    let i = 0;
    function showNext() {
      track.innerHTML = `<span class="ticker-item">${TICKER_ITEMS[i % TICKER_ITEMS.length]}</span>`;
      i++;
    }
    showNext();
    setInterval(showNext, 8000);
  }

  function initThemeToggle() {
    const buttons = $$('.theme-toggle');
    if (!buttons.length) return;
    const stored = localStorage.getItem('eh-theme');
    const setPressed = isDark => buttons.forEach(button => button.setAttribute('aria-pressed', String(isDark)));
    if (stored === 'dark') {
      document.documentElement.setAttribute('data-theme', 'dark');
      setPressed(true);
    } else {
      setPressed(false);
    }
    buttons.forEach(button => button.addEventListener('click', () => {
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      if (isDark) {
        document.documentElement.removeAttribute('data-theme');
        localStorage.setItem('eh-theme', 'light');
      } else {
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('eh-theme', 'dark');
      }
      setPressed(!isDark);
      showToast(isDark ? 'Light mode on' : 'Dark mode on', '🌓');
    }));
  }

  function initHamburger() {
    const btn = $('#hamburgerBtn');
    const nav = $('#primaryNav');
    if (!btn || !nav) return;
    btn.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      btn.classList.toggle('active', open);
      btn.setAttribute('aria-expanded', String(open));
      document.body.style.overflow = open ? 'hidden' : '';
    });
    // Mobile mega menu toggle
    $$('.has-mega > a', nav).forEach(link => {
      link.addEventListener('click', (e) => {
        if (window.innerWidth <= 992) {
          e.preventDefault();
          link.parentElement.classList.toggle('open');
        }
      });
    });
  }

  function initSearch() {
    const trigger = $('#searchTrigger');
    const panel = $('#searchPanel');
    const closeBtn = $('#searchClose');
    const input = $('#searchInput');
    const suggestions = $('#searchSuggestions');
    if (!trigger || !panel) return;

    const searchIndex = [
      ...NEWS.map(n => ({ title: n.title, type: 'News' })),
      ...MOVIES.map(m => ({ title: m.title, type: 'Movie' })),
      ...OTT.map(o => ({ title: o.title, type: 'OTT Show' })),
      ...CELEBS.map(c => ({ title: c.name, type: 'Celebrity' }))
    ];

    function open() {
      panel.classList.add('open');
      trigger.setAttribute('aria-expanded', 'true');
      setTimeout(() => input.focus(), 300);
    }
    function close() {
      panel.classList.remove('open');
      trigger.setAttribute('aria-expanded', 'false');
      suggestions.innerHTML = '';
      input.value = '';
    }
    trigger.addEventListener('click', () => panel.classList.contains('open') ? close() : open());
    closeBtn.addEventListener('click', close);
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });

    input.addEventListener('input', () => {
      const q = input.value.trim().toLowerCase();
      if (!q) { suggestions.innerHTML = ''; return; }
      const matches = searchIndex.filter(item => item.title.toLowerCase().includes(q)).slice(0, 6);
      if (!matches.length) {
        suggestions.innerHTML = `<p style="padding:8px 12px;color:var(--color-text-soft);font-size:0.86rem;">No results for “${q}”.</p>`;
        return;
      }
      suggestions.innerHTML = matches.map(m => {
        const idx = m.title.toLowerCase().indexOf(q);
        const highlighted = m.title.slice(0, idx) + '<mark>' + m.title.slice(idx, idx + q.length) + '</mark>' + m.title.slice(idx + q.length);
        return `<a href="#">${highlighted} <span style="color:var(--color-text-soft);font-size:0.76rem;">— ${m.type}</span></a>`;
      }).join('');
    });
  }

  /* ---------------------------------------------------------------
     4a. LIVE TV — YouTube live news channel embed
  ------------------------------------------------------------------ */
  function getAdminLiveStream() {
    try {
      const settings = window.__EH_PUBLIC?.liveStream;
      const videoId = String(settings?.videoId || '').trim();
      if (!/^[A-Za-z0-9_-]{11}$/.test(videoId)) return null;
      return { videoId, name: String(settings.title || 'RedCrab Live').trim() || 'RedCrab Live' };
    } catch (error) {
      return null;
    }
  }

  function buildLiveSrc(channelId, muted) {
    return `https://www.youtube.com/embed/live_stream?channel=${channelId}&autoplay=1&mute=${muted ? 1 : 0}&rel=0`;
  }

  function buildVideoLiveSrc(videoId, muted) {
    return `https://www.youtube.com/embed/${videoId}?autoplay=1&mute=${muted ? 1 : 0}&rel=0`;
  }

  function initLiveTV() {
    const tabsWrap = $('#channelTabs');
    const iframe = $('#liveIframe');
    const nowLabel = $('#liveNowLabel');
    const viewerCount = $('#viewerCount');
    const muteBtn = $('#liveMuteToggle');
    const prevBtn = $('#livePrevChannel');
    const nextBtn = $('#liveNextChannel');
    if (!tabsWrap || !iframe) return;

    const adminLiveStream = getAdminLiveStream();
    const channels = adminLiveStream ? [adminLiveStream] : LIVE_CHANNELS;
    const hasAdminLiveStream = Boolean(adminLiveStream);
    let current = 0;
    let muted = true;

    tabsWrap.innerHTML = channels.map((c, i) =>
      `<button class="channel-tab ${i === 0 ? 'active' : ''}" data-index="${i}" role="tab" aria-selected="${i === 0}">${c.name}</button>`
    ).join('');
    tabsWrap.style.display = hasAdminLiveStream ? 'none' : '';
    if (prevBtn) prevBtn.hidden = hasAdminLiveStream;
    if (nextBtn) nextBtn.hidden = hasAdminLiveStream;

    function load(index, notify = false) {
      current = (index + channels.length) % channels.length;
      const channel = channels[current];
      iframe.src = channel.videoId ? buildVideoLiveSrc(channel.videoId, muted) : buildLiveSrc(channel.id, muted);
      nowLabel.textContent = channel.name;
      $$('.channel-tab', tabsWrap).forEach((t, i) => {
        t.classList.toggle('active', i === current);
        t.setAttribute('aria-selected', String(i === current));
      });
      muteBtn.textContent = muted ? '🔇 Unmute' : '🔊 Mute';
      if (notify) showToast(`Now watching ${channel.name} — live`, '📡');
    }

    tabsWrap.addEventListener('click', (e) => {
      const btn = e.target.closest('.channel-tab');
      if (!btn) return;
      load(Number(btn.dataset.index), true);
    });
    prevBtn?.addEventListener('click', () => load(current - 1, true));
    nextBtn?.addEventListener('click', () => load(current + 1, true));
    muteBtn?.addEventListener('click', () => {
      muted = !muted;
      load(current);
    });

    // Simulated live viewer counter — ticks gently to feel alive.
    let viewers = 12000 + Math.floor(Math.random() * 4000);
    function tickViewers() {
      viewers += Math.floor(Math.random() * 120) - 40;
      viewers = Math.max(8000, viewers);
      if (viewerCount) viewerCount.textContent = `👁 ${viewers.toLocaleString('en-IN')} watching`;
    }
    tickViewers();
    setInterval(tickViewers, 4000);

    load(0);
  }

  /* ---------------------------------------------------------------
     4. HERO SLIDER
  ------------------------------------------------------------------ */
  function initHeroSlider() {
    const track = $('#heroTrack');
    const dotsWrap = $('#heroDots');
    if (!track) return;
    let savedSlides = [];
    try {
      const adminData = window.__EH_PUBLIC || null;
      if (Array.isArray(adminData?.slides)) savedSlides = adminData.slides.filter(slide => slide.title && slide.image).slice(-5).reverse();
    } catch (error) {
      savedSlides = [];
    }
    const slidesData = savedSlides.length ? savedSlides.map(slide => ({
      ...slide,
      tagline: slide.tagline || 'Trending',
      category: slide.category || 'Movies',
      date: slide.date || 'Today',
      readTime: Number(slide.readTime) || 3,
      views: Number(slide.views) || 0
    })) : NEWS.slice(0, 5).map((story, i) => ({
      ...story,
      image: seedImg('hero' + i, 1200, 700),
      tagline: 'Trending',
      readTime: 3 + i,
      views: story.views * 10
    }));
    let current = 0;
    let timer = null;

    track.innerHTML = slidesData.map((n, i) => `
      <div class="hero-slide" style="background-image:url('${n.image}')" role="group" aria-label="Slide ${i + 1} of ${slidesData.length}">
        <div class="hero-content">
          <div class="hero-meta">
            <span class="badge badge-trending">🔥 ${n.tagline}</span>
            <span class="badge badge-category">${n.category}</span>
            <span class="meta-sep">•</span>
            <span class="meta-text">${n.date}</span>
            <span class="meta-sep">•</span>
            <span class="meta-text">${n.readTime} min read</span>
            <span class="meta-sep">•</span>
            <span class="meta-text">👁 ${n.views}</span>
          </div>
          <h1 class="hero-title">${n.title}</h1>
          <div class="hero-actions">
            <a href="article.html" class="btn btn-primary">Read Full Story</a>
            <button class="icon-btn bookmark-btn" data-id="hero-${i}" aria-label="Bookmark">🔖</button>
            <button class="icon-btn share-btn" data-id="hero-${i}" aria-label="Share">↗</button>
          </div>
        </div>
      </div>`).join('');

    dotsWrap.innerHTML = slidesData.map((_, i) => `<button role="tab" aria-label="Go to slide ${i + 1}" class="${i === 0 ? 'active' : ''}"></button>`).join('');
    const dots = $$('button', dotsWrap);

    function goTo(i) {
      current = (i + slidesData.length) % slidesData.length;
      track.style.transform = `translateX(-${current * 100}%)`;
      dots.forEach((d, idx) => d.classList.toggle('active', idx === current));
    }
    function restartAutoplay() {
      clearInterval(timer);
      timer = setInterval(() => goTo(current + 1), 6000);
    }
    $('#heroPrev').addEventListener('click', () => { goTo(current - 1); restartAutoplay(); });
    $('#heroNext').addEventListener('click', () => { goTo(current + 1); restartAutoplay(); });
    dots.forEach((d, i) => d.addEventListener('click', () => { goTo(i); restartAutoplay(); }));

    // Swipe support
    let touchStartX = 0;
    track.addEventListener('touchstart', (e) => { touchStartX = e.touches[0].clientX; }, { passive: true });
    track.addEventListener('touchend', (e) => {
      const dx = e.changedTouches[0].clientX - touchStartX;
      if (Math.abs(dx) > 50) { goTo(current + (dx < 0 ? 1 : -1)); restartAutoplay(); }
    }, { passive: true });

    goTo(0);
    restartAutoplay();
  }

  /* ---------------------------------------------------------------
     5. SECTION RENDERERS
  ------------------------------------------------------------------ */
  function trendingCardHTML(n) {
    return `
      <article class="card" data-reveal>
        <div class="card-media">
          <img src="${n.img}" alt="${n.title}" loading="lazy" width="500" height="320">
          <span class="badge badge-category">${n.category}</span>
        </div>
        <div class="card-body">
          <h3 class="card-title"><a href="article.html">${n.title}</a></h3>
          <p class="card-desc">${n.desc}</p>
          <div class="card-foot">
            <div class="card-author"><span class="author-avatar"></span>${n.author} · ${n.date}</div>
            <span>👁 ${n.views}</span>
          </div>
          ${cardActionsHTML(n.id)}
        </div>
      </article>`;
  }

  function renderTrending() {
    const grid = $('#trendingGrid');
    if (!grid) return;
    grid.innerHTML = Array.from({ length: 6 }).map(() => `
      <div class="skeleton-card"><div class="skeleton-media"></div><div class="skeleton-line"></div><div class="skeleton-line short"></div></div>
    `).join('');
    setTimeout(() => {
      grid.innerHTML = NEWS.filter(n => n.trending).slice(0, 6).map(trendingCardHTML).join('');
      revealNewCards(grid);
    }, 500);
  }

  function movieCardHTML(m) {
    return `
      <article class="card" data-reveal data-status="${m.status}">
        <div class="card-media">
          <img src="${m.img}" alt="${m.title}" loading="lazy" width="480" height="300">
          <span class="badge badge-category">${m.genre}</span>
        </div>
        <div class="card-body">
          <h3 class="card-title"><a href="article.html">${m.title}</a></h3>
          <div class="movie-rating"><span class="star">★</span> ${m.rating} / 10</div>
          ${m.status === 'latest' ? `<div class="boxoffice-bar" aria-label="Box office ${m.boxoffice} crore"><span style="width:${Math.min(m.boxoffice, 100)}%"></span></div><p class="card-desc">₹${m.boxoffice} Cr box office collection</p>` : `<p class="card-desc">In cinemas ${m.date}</p>`}
          <div class="card-foot">
            <a href="#" class="btn btn-outline btn-sm">▶ Trailer</a>
            ${cardActionsHTML(m.id)}
          </div>
        </div>
      </article>`;
  }

  function renderMovies(filter = 'latest') {
    const grid = $('#movieGrid');
    if (!grid) return;
    let list = MOVIES;
    if (filter === 'latest') list = MOVIES.filter(m => m.status === 'latest');
    if (filter === 'upcoming') list = MOVIES.filter(m => m.status === 'upcoming');
    if (filter === 'boxoffice') list = [...MOVIES].sort((a, b) => b.boxoffice - a.boxoffice);
    grid.innerHTML = list.slice(0, 8).map(movieCardHTML).join('');
    revealNewCards(grid);
  }

  function ottCardHTML(o) {
    return `
      <article class="card" data-reveal>
        <div class="card-media">
          <img src="${o.img}" alt="${o.title}" loading="lazy" width="480" height="300">
          <span class="badge badge-category">${o.tag}</span>
        </div>
        <div class="card-body">
          <h3 class="card-title"><a href="article.html">${o.title}</a></h3>
          <p class="card-desc">${o.platform} · ${o.seasons} season${o.seasons > 1 ? 's' : ''}</p>
          <div class="card-foot">
            <a href="#" class="btn btn-outline btn-sm">▶ Watch Now</a>
            ${cardActionsHTML(o.id)}
          </div>
        </div>
      </article>`;
  }

  function renderOTT(platform = 'All') {
    const chips = $('#platformChips');
    const grid = $('#ottGrid');
    if (!grid) return;
    if (chips && !chips.dataset.built) {
      chips.dataset.built = '1';
      chips.innerHTML = ['All', ...OTT_PLATFORMS].map(p => `<button class="platform-chip ${p === 'All' ? 'active' : ''}" data-platform="${p}">${p}</button>`).join('');
      chips.addEventListener('click', (e) => {
        const btn = e.target.closest('.platform-chip');
        if (!btn) return;
        $$('.platform-chip', chips).forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        renderOTT(btn.dataset.platform);
      });
    }
    const list = platform === 'All' ? OTT : OTT.filter(o => o.platform === platform);
    grid.innerHTML = (list.length ? list : OTT).slice(0, 8).map(ottCardHTML).join('');
    revealNewCards(grid);
  }

  function celebCardHTML(c) {
    return `
      <article class="card celeb-card" data-reveal>
        <div class="card-media">
          <img src="${c.img}" alt="${c.name}" loading="lazy" width="400" height="400">
        </div>
        <div class="card-body">
          <span class="celeb-tag">${c.tag}</span>
          <h3 class="card-title">${c.name}</h3>
          <p class="card-desc">${c.role}</p>
          ${cardActionsHTML(c.id)}
        </div>
      </article>`;
  }

  function renderCelebs() {
    const grid = $('#celebGrid');
    if (!grid) return;
    grid.innerHTML = CELEBS.map(celebCardHTML).join('');
    revealNewCards(grid);
  }

  function videoCardHTML(v) {
    const ytId = v.yt || pick(SAMPLE_YT_IDS, 0);
    return `
      <article class="card" data-reveal>
        <div class="card-media" data-yt-open="${ytId}" role="button" tabindex="0" aria-label="Play ${v.title}">
          <img src="${v.img}" alt="${v.title}" loading="lazy" width="480" height="280">
          <div class="card-play"><span>▶</span></div>
          <span class="duration-badge">${v.duration}</span>
        </div>
        <div class="card-body">
          <h3 class="card-title">${v.title}</h3>
          ${cardActionsHTML(v.id)}
        </div>
      </article>`;
  }

  function renderVideos() {
    const grid = $('#videoGrid');
    if (!grid) return;
    const adminVideos = getAdminGalleryMedia().videos.map(video => ({
      id: video.id,
      title: video.title,
      duration: video.duration || '3:00',
      img: video.thumbnail || `https://i.ytimg.com/vi/${video.videoId}/hqdefault.jpg`,
      yt: video.videoId
    }));
    const videos = [...adminVideos, ...VIDEOS.map((video, i) => ({ ...video, yt: pick(SAMPLE_YT_IDS, i) }))];
    grid.innerHTML = videos.map(videoCardHTML).join('');
    revealNewCards(grid);
    if (grid.classList.contains('video-slider')) {
      initAutoSlider(
        grid.closest('#videos'),
        grid,
        '.card',
        '.video-slider-prev',
        '.video-slider-next'
      );
    }
  }

  function initAutoSlider(section, grid, itemSelector, previousSelector, nextSelector) {
    const previous = section?.querySelector(previousSelector);
    const next = section?.querySelector(nextSelector);
    if (!section || !previous || !next) return;

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    let timer;
    const slideStep = () => {
      const item = grid.querySelector(itemSelector);
      if (!item) return 0;
      const styles = getComputedStyle(grid);
      return item.getBoundingClientRect().width + parseFloat(styles.columnGap || styles.gap || '0');
    };
    const advance = (direction = 1) => {
      const step = slideStep();
      if (!step) return;
      const maxScroll = grid.scrollWidth - grid.clientWidth;
      const target = grid.scrollLeft + step * direction;
      grid.scrollTo({
        left: direction > 0 && target >= maxScroll - 2 ? 0 : direction < 0 && target < 0 ? maxScroll : target,
        behavior: reducedMotion.matches ? 'auto' : 'smooth'
      });
    };
    const stopAutoSlide = () => window.clearInterval(timer);
    const startAutoSlide = () => {
      stopAutoSlide();
      if (!reducedMotion.matches && !document.hidden && !section.matches(':hover') && !section.contains(document.activeElement)) {
        timer = window.setInterval(() => advance(), 3500);
      }
    };

    previous.addEventListener('click', () => advance(-1));
    next.addEventListener('click', () => advance());
    section.addEventListener('mouseenter', stopAutoSlide);
    section.addEventListener('mouseleave', startAutoSlide);
    section.addEventListener('focusin', stopAutoSlide);
    section.addEventListener('focusout', event => {
      if (!section.contains(event.relatedTarget) && !section.matches(':hover')) startAutoSlide();
    });
    grid.addEventListener('touchstart', stopAutoSlide, { passive: true });
    grid.addEventListener('touchend', () => window.setTimeout(startAutoSlide, 5000), { passive: true });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) stopAutoSlide();
      else if (!section.matches(':hover') && !section.contains(document.activeElement)) startAutoSlide();
    });
    reducedMotion.addEventListener('change', startAutoSlide);
    startAutoSlide();
  }

  function renderGallery() {
    const grid = $('#galleryGrid');
    if (!grid) return;
    grid.innerHTML = getGalleryPhotos().map((g, i) => `
      <div class="masonry-item" data-index="${i}" tabindex="0" role="button" aria-label="Open ${g.caption} in lightbox">
        <img src="${g.img}" alt="${g.caption}" loading="lazy">
      </div>`).join('');

    if (!grid.classList.contains('gallery-slider')) return;
    initAutoSlider(grid.closest('#gallery'), grid, '.masonry-item', '.gallery-slider-prev', '.gallery-slider-next');
  }

  /* ---------------------------------------------------------------
     5a. CLIENTS / PARTNERS MARQUEE
  ------------------------------------------------------------------ */
  function clientLogoHTML(c) {
    return `<div class="client-logo" title="${c.name}"><img src="${c.img}" alt="${c.name}" loading="lazy"></div>`;
  }

  function renderClients() {
    const track = $('#clientsTrack');
    if (!track) return;
    const html = CLIENTS.map(clientLogoHTML).join('');
    track.innerHTML = html + html; // duplicated for seamless marquee loop
  }

  /* ---------------------------------------------------------------
     5b. EVENTS — Government & Entertainment
  ------------------------------------------------------------------ */
  function eventCardHTML(e) {
    return `
      <article class="card event-card" data-reveal>
        <div class="card-media">
          <img src="${e.img}" alt="${e.name}" loading="lazy" width="480" height="300">
          <span class="badge badge-category">${e.date}</span>
        </div>
        <div class="card-body">
          <h3 class="card-title">${e.name}</h3>
          <div class="event-meta-row"><span>📅 ${e.date}</span><span>📍 ${e.venue}</span></div>
          <p class="card-desc">${e.desc}</p>
        </div>
      </article>`;
  }

  function renderGovEvents() {
    const grid = $('#govEventsGrid');
    if (!grid) return;
    grid.innerHTML = GOV_EVENTS.map(eventCardHTML).join('');
    revealNewCards(grid);
  }

  function renderEntEvents() {
    const grid = $('#entEventsGrid');
    if (!grid) return;
    grid.innerHTML = ENT_EVENTS.map(eventCardHTML).join('');
    revealNewCards(grid);
  }

  /* ---------------------------------------------------------------
     5c. OFFICIAL YOUTUBE VIDEOS
  ------------------------------------------------------------------ */
  function renderOfficialYouTube() {
    const grid = $('#officialYoutubeGrid');
    if (!grid) return;
    grid.innerHTML = OFFICIAL_YT.map(videoCardHTML).join('');
    revealNewCards(grid);
  }

  /* ---------------------------------------------------------------
     5d. RECENT SHORTS (horizontal, 20-second videos)
  ------------------------------------------------------------------ */
  function shortCardHTML(s) {
    return `
      <div class="short-card" data-yt-open="${s.yt}" tabindex="0" role="button" aria-label="Play ${s.caption}">
        <img src="${s.img}" alt="${s.caption}" loading="lazy">
        <div class="short-play"><span>▶</span></div>
        <span class="short-duration">${s.duration}</span>
      </div>`;
  }

  function renderShorts() {
    const row = $('#shortsRow');
    if (!row) return;
    const adminShorts = getAdminGalleryMedia().shorts.map(short => ({
      id: short.id,
      caption: short.title,
      duration: short.duration || '0:20',
      img: short.thumbnail || `https://i.ytimg.com/vi/${short.videoId}/hqdefault.jpg`,
      yt: short.videoId
    }));
    row.innerHTML = [...adminShorts, ...SHORTS].map(shortCardHTML).join('');
  }

  /* ---------------------------------------------------------------
     5e. RECENT BLOGS (replaces Popular Articles widget)
  ------------------------------------------------------------------ */
  function getAdminBlogPosts() {
    try {
      const posts = window.__EH_PUBLIC?.blogPosts;
      return Array.isArray(posts) ? posts.slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt)) : [];
    } catch (error) {
      return [];
    }
  }

  function blogItemHTML(b) {
    return `<li><img src="${b.img}" alt="" loading="lazy"><a href="article.html" class="pop-title">${b.title}<br><span style="color:var(--color-text-soft);font-size:0.74rem;">${b.date}</span></a></li>`;
  }

  function renderBlogs(tab = 'latest') {
    const list = $('#blogsList');
    if (!list) return;
    const adminPosts = getAdminBlogPosts();
    const featuredPosts = adminPosts.filter(post => post.trending);
    const items = tab === 'trending'
      ? [...featuredPosts, ...[...BLOGS].reverse()]
      : [...adminPosts, ...BLOGS];
    list.innerHTML = items.slice(0, 6).map(blogItemHTML).join('');
  }

  function initBlogsWidget() {
    renderBlogs();
    const tabsWrap = $('#blogsTabs');
    if (!tabsWrap) return;
    tabsWrap.addEventListener('click', (e) => {
      const btn = e.target.closest('.wtab');
      if (!btn) return;
      $$('.wtab', tabsWrap).forEach(t => t.classList.remove('active'));
      btn.classList.add('active');
      renderBlogs(btn.dataset.btab);
    });
  }

  /* ---------------------------------------------------------------
     5f. AWARDS PAGE
  ------------------------------------------------------------------ */
  function awardCardHTML(a) {
    return `
      <article class="card award-card" data-reveal>
        <div class="card-media">
          <img src="${a.img}" alt="${a.title}" loading="lazy" width="480" height="300">
        </div>
        <div class="card-body">
          <span class="award-org">${a.org}</span>
          <h3 class="card-title">${a.title}</h3>
          <span class="award-date">📅 ${a.date}</span>
          <p class="card-desc">${a.desc}</p>
        </div>
      </article>`;
  }

  function renderAwards() {
    const grid = $('#awardsGrid');
    if (!grid) return;
    grid.innerHTML = AWARDS.map(awardCardHTML).join('');
    revealNewCards(grid);
  }

  /* ---------------------------------------------------------------
     5g. INTERVIEWS PAGE
  ------------------------------------------------------------------ */
  function interviewCardHTML(iv) {
    return `
      <article class="card interview-card" data-reveal>
        <div class="card-media" data-yt-open="${iv.yt}" role="button" tabindex="0" aria-label="Watch ${iv.title}">
          <img src="${iv.img}" alt="${iv.title}" loading="lazy" width="480" height="300">
          <div class="card-play"><span>▶</span></div>
        </div>
        <div class="card-body">
          <h3 class="card-title">${iv.title}</h3>
          <p class="card-desc">${iv.desc}</p>
          <div class="card-foot">
            <button class="btn btn-outline btn-sm" data-yt-open="${iv.yt}">▶ Watch Interview</button>
          </div>
        </div>
      </article>`;
  }

  function renderInterviews() {
    const grid = $('#interviewsGrid');
    if (!grid) return;
    grid.innerHTML = INTERVIEWS.map(interviewCardHTML).join('');
    revealNewCards(grid);
  }

  /* ---------------------------------------------------------------
     5h. VIDEO MODAL (shared popup for all video/interview/shorts clicks)
  ------------------------------------------------------------------ */
  function ensureVideoModal() {
    if ($('#videoModalOverlay')) return;
    const overlay = document.createElement('div');
    overlay.id = 'videoModalOverlay';
    overlay.className = 'video-modal';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-hidden', 'true');
    overlay.innerHTML = `
      <div class="video-modal-inner">
        <button class="video-modal-close" id="videoModalClose" aria-label="Close video">✕</button>
        <div class="video-modal-frame">
          <iframe id="videoModalIframe" src="" title="Video player" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen loading="lazy"></iframe>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    $('#videoModalClose').addEventListener('click', closeVideoModal);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeVideoModal(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeVideoModal(); });
  }

  function openVideoModal(ytId) {
    if (!ytId) return;
    ensureVideoModal();
    const overlay = $('#videoModalOverlay');
    const iframe = $('#videoModalIframe');
    iframe.src = `https://www.youtube.com/embed/${ytId}?autoplay=1&rel=0`;
    overlay.classList.add('open');
    overlay.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeVideoModal() {
    const overlay = $('#videoModalOverlay');
    if (!overlay) return;
    overlay.classList.remove('open');
    overlay.setAttribute('aria-hidden', 'true');
    const iframe = $('#videoModalIframe');
    if (iframe) iframe.src = '';
    document.body.style.overflow = '';
  }

  function initVideoModalTriggers() {
    document.addEventListener('click', (e) => {
      const trigger = e.target.closest('[data-yt-open]');
      if (!trigger) return;
      e.preventDefault();
      openVideoModal(trigger.dataset.ytOpen);
    });
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      const trigger = e.target.closest('[data-yt-open]');
      if (!trigger) return;
      e.preventDefault();
      openVideoModal(trigger.dataset.ytOpen);
    });
  }

  /* ---------------------------------------------------------------
     5i. PREDEFINED CHATBOT (rule-based, no external API)
  ------------------------------------------------------------------ */
  const CHATBOT_QUICK_REPLIES = [
    { label: 'Event Details', key: 'event' },
    { label: 'Contact Info', key: 'contact' },
    { label: 'Awards', key: 'award' },
    { label: 'Gallery', key: 'gallery' },
    { label: 'Booking Info', key: 'booking' }
  ];

  function getBotReply(rawText) {
    const text = rawText.toLowerCase();
    if (/(event|venue|schedule|calendar)/.test(text)) {
      return 'We host both Government Events and Entertainment Events — you can find dates, venues and details in the Events sections on our homepage. Looking for something specific?';
    }
    if (/(contact|email|phone|reach|support)/.test(text)) {
      return 'You can reach us via our Contact page — it has our office address, phone number and a quick message form. Just click "Contact" in the menu.';
    }
    if (/(award)/.test(text)) {
      return 'Our Awards page lists every category with the image, title, organisation, date and a short description for each honour. Tap "Awards" in the top menu to explore.';
    }
    if (/(gallery|photo|picture|image)/.test(text)) {
      return 'Our Photo Gallery is on the homepage — just scroll to the "Photo Gallery" section and click any image to open it full-screen.';
    }
    if (/(video|trailer|watch|youtube|short)/.test(text)) {
      return 'You can watch trailers, Official YouTube Videos and quick 20-second Shorts right on the homepage — clicking any thumbnail opens it in a popup player.';
    }
    if (/(book|booking|ticket|reserve)/.test(text)) {
      return 'For booking or reservation enquiries, please use the Contact page and select "Advertising Enquiry" or leave us a message — our team will get back to you with booking details.';
    }
    if (/(hi|hello|hey)/.test(text)) {
      return 'Hello! 👋 I can help with Event Details, Contact Info, Awards, Gallery or Booking Info. What would you like to know?';
    }
    if (/(thank)/.test(text)) {
      return 'You\'re welcome! Let me know if there\'s anything else you\'d like to know.';
    }
    return 'I\'m a simple assistant and can help with a few topics: Event Details, Contact Info, Awards, Gallery, or Booking Info. Try one of the quick options below!';
  }

  function enableSlideoutTap(panel, link) {
    if (!panel || !link || link.dataset.slideoutTapReady === 'true') return;
    link.dataset.slideoutTapReady = 'true';
    link.setAttribute('aria-expanded', 'false');

    link.addEventListener('click', event => {
      if (!window.matchMedia('(hover: none), (pointer: coarse)').matches || panel.classList.contains('is-open')) return;
      event.preventDefault();
      document.querySelectorAll('.free2speak-promo.is-open, .whatsapp-float.is-open').forEach(openPanel => {
        openPanel.classList.remove('is-open');
        openPanel.querySelector('a')?.setAttribute('aria-expanded', 'false');
      });
      panel.classList.add('is-open');
      link.setAttribute('aria-expanded', 'true');
    });

    document.addEventListener('pointerdown', event => {
      if (panel.contains(event.target)) return;
      panel.classList.remove('is-open');
      link.setAttribute('aria-expanded', 'false');
    });
  }

  function ensureFree2SpeakPromo() {
    let promo = $('#free2speakPromo');
    if (!promo) {
      promo = document.createElement('aside');
      promo.id = 'free2speakPromo';
      promo.className = 'free2speak-promo';
      promo.setAttribute('aria-label', 'Free2Speak app promotion');

      const link = document.createElement('a');
      link.className = 'free2speak-link';
      link.href = 'https://free2speak.in/';
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.setAttribute('aria-label', 'Visit Free2Speak');

      const logo = document.createElement('img');
      logo.className = 'free2speak-logo';
      logo.src = 'https://free2speak.in/assets/Free2speak_Logo.png';
      logo.alt = 'Free2Speak';

      const name = document.createElement('span');
      name.className = 'free2speak-name';
      name.textContent = 'Free2Speak';

      link.append(logo, name);
      promo.appendChild(link);
      document.body.appendChild(promo);
    }
    enableSlideoutTap(promo, promo.querySelector('a'));
  }

  function ensureChatbot() {
    if ($('#chatbotToggle')) return;
    const toggle = document.createElement('button');
    toggle.id = 'chatbotToggle';
    toggle.className = 'chatbot-toggle';
    toggle.setAttribute('aria-label', 'Open chat assistant');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.innerHTML = '<svg viewBox="0 0 64 64" aria-hidden="true" focusable="false"><defs><linearGradient id="chatbotStroke" x1="8" y1="56" x2="56" y2="8" gradientUnits="userSpaceOnUse"><stop stop-color="#16c8f4"/><stop offset="1" stop-color="#d62cff"/></linearGradient></defs><path class="bot-antenna" d="M32 14V9"/><circle class="bot-signal" cx="32" cy="6" r="2.5"/><rect class="bot-face" x="14" y="15" width="36" height="27" rx="4"/><g class="bot-arm bot-arm-left"><path d="M14 24h-3a5 5 0 0 0-5 5v4a5 5 0 0 0 5 5h3"/><circle cx="6" cy="40" r="3"/></g><g class="bot-arm bot-arm-right"><path d="M50 24h3a5 5 0 0 1 5 5v4a5 5 0 0 1-5 5h-3"/><circle cx="58" cy="40" r="3"/></g><circle class="bot-eye" cx="25" cy="27" r="1.7"/><circle class="bot-eye" cx="39" cy="27" r="1.7"/><path class="bot-smile" d="M25 34h14"/><path class="bot-base" d="M19 44c2 10 7 15 13 15s11-5 13-15"/><path d="m21 48-5 6m27-6 5 6"/></svg>';
    document.body.appendChild(toggle);

    const whatsapp = document.createElement('a');
    whatsapp.className = 'whatsapp-float';
    whatsapp.href = 'https://wa.me/919338258445';
    whatsapp.target = '_blank';
    whatsapp.rel = 'noopener noreferrer';
    whatsapp.setAttribute('aria-label', 'Chat with RedCrab on WhatsApp');
    whatsapp.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M20.5 3.5A11.8 11.8 0 0 0 12.1 0C5.5 0 .2 5.3.2 11.9c0 2.1.5 4.1 1.6 5.9L0 24l6.3-1.7a11.9 11.9 0 0 0 5.7 1.5h.1c6.5 0 11.9-5.3 11.9-11.9a11.8 11.8 0 0 0-3.5-8.4ZM12 21.8h-.1a9.8 9.8 0 0 1-5-1.4l-.4-.2-3.7 1 1-3.7-.2-.4a9.8 9.8 0 0 1-1.5-5.2C2.1 6.5 6.5 2.1 12 2.1a9.8 9.8 0 0 1 7 2.9 9.8 9.8 0 0 1 2.9 7c0 5.4-4.4 9.8-9.9 9.8Zm5.4-7.3c-.3-.1-1.8-.9-2.1-1-.3-.1-.5-.1-.7.2l-.9 1.1c-.2.2-.3.2-.6.1-.3-.2-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.1-.3 0-.4.1-.6l.5-.5c.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5L9 7c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.2.2 2.1 3.2 5.1 4.5.7.3 1.3.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.8-.7 2-1.4.3-.7.3-1.3.2-1.4-.1-.2-.3-.3-.6-.4Z"/></svg><span class="whatsapp-label">WhatsApp</span>';
    document.body.appendChild(whatsapp);
    enableSlideoutTap(whatsapp, whatsapp);

    const panel = document.createElement('div');
    panel.id = 'chatbotPanel';
    panel.className = 'chatbot-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-hidden', 'true');
    panel.setAttribute('aria-label', 'Chat assistant');
    panel.innerHTML = `
      <div class="chatbot-head">
        <span>RedCrab Assistant</span>
        <button class="chatbot-close" id="chatbotClose" aria-label="Close chat">✕</button>
      </div>
      <div class="chatbot-messages" id="chatbotMessages" aria-live="polite"></div>
      <div class="chatbot-quick" id="chatbotQuick">
        ${CHATBOT_QUICK_REPLIES.map(q => `<button type="button" data-qkey="${q.key}">${q.label}</button>`).join('')}
      </div>
      <form class="chatbot-input-row" id="chatbotForm">
        <label for="chatbotInput" class="sr-only">Type your question</label>
        <input type="text" id="chatbotInput" placeholder="Ask about events, awards, gallery…" autocomplete="off">
        <button type="submit" aria-label="Send message">➤</button>
      </form>`;
    document.body.appendChild(panel);

    const messages = $('#chatbotMessages');
    function addMessage(text, who) {
      const div = document.createElement('div');
      div.className = `chat-msg ${who}`;
      div.textContent = text;
      messages.appendChild(div);
      messages.scrollTop = messages.scrollHeight;
    }
    addMessage('Hi there! I\'m the RedCrab Entertainment assistant. Ask me about Event Details, Contact Info, Awards, Gallery or Booking Info.', 'bot');

    function open() {
      panel.classList.add('open');
      toggle.setAttribute('aria-expanded', 'true');
      panel.setAttribute('aria-hidden', 'false');
    }
    function close() {
      panel.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
      panel.setAttribute('aria-hidden', 'true');
      toggle.focus();
    }
    toggle.addEventListener('click', () => panel.classList.contains('open') ? close() : open());
    $('#chatbotClose').addEventListener('click', close);

    $('#chatbotQuick').addEventListener('click', (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;
      const q = CHATBOT_QUICK_REPLIES.find(r => r.key === btn.dataset.qkey);
      addMessage(q.label, 'user');
      setTimeout(() => addMessage(getBotReply(q.key), 'bot'), 350);
    });

    $('#chatbotForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const input = $('#chatbotInput');
      const value = input.value.trim();
      if (!value) return;
      addMessage(value, 'user');
      input.value = '';
      setTimeout(() => addMessage(getBotReply(value), 'bot'), 350);
    });
  }

  function initChatbot() {
    ensureFree2SpeakPromo();
    ensureChatbot();
  }

  function revealNewCards(container) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('reveal');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    $$('.card', container).forEach((card, i) => {
      card.style.transitionDelay = `${(i % 4) * 60}ms`;
      observer.observe(card);
    });
  }

  /* ---------------------------------------------------------------
     6. LATEST NEWS — filter + load more
  ------------------------------------------------------------------ */
  let latestPage = 0;
  const LATEST_PAGE_SIZE = 4;

  function latestCardHTML(n) {
    return `
      <article class="card" data-reveal data-category="${n.category}">
        <div class="card-media">
          <img src="${n.img}" alt="${n.title}" loading="lazy" width="500" height="320">
          <span class="badge badge-category">${n.category}</span>
        </div>
        <div class="card-body">
          <h3 class="card-title"><a href="article.html">${n.title}</a></h3>
          <p class="card-desc">${n.desc}</p>
          <div class="card-foot">
            <div class="card-author"><span class="author-avatar"></span>${n.author} · ${n.date}</div>
            <span>👁 ${n.views}</span>
          </div>
          ${cardActionsHTML(n.id)}
        </div>
      </article>`;
  }

  function getFilteredNews() {
    const select = $('#categoryFilter');
    const val = select ? select.value : 'all';
    return val === 'all' ? NEWS : NEWS.filter(n => n.category === val);
  }

  function renderLatestPage(reset = false) {
    const grid = $('#latestGrid');
    const loadMoreBtn = $('#loadMoreBtn');
    if (!grid) return;
    if (reset) { latestPage = 0; grid.innerHTML = ''; }
    const filtered = getFilteredNews();
    const start = latestPage * LATEST_PAGE_SIZE;
    const slice = filtered.slice(start, start + LATEST_PAGE_SIZE);
    grid.insertAdjacentHTML('beforeend', slice.map(latestCardHTML).join(''));
    revealNewCards(grid);
    latestPage++;
    if (loadMoreBtn) loadMoreBtn.style.display = (latestPage * LATEST_PAGE_SIZE >= filtered.length) ? 'none' : 'inline-flex';
  }

  function initLatestNews() {
    const select = $('#categoryFilter');
    if (select) {
      CATEGORIES.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c; opt.textContent = c;
        select.appendChild(opt);
      });
      select.addEventListener('change', () => renderLatestPage(true));
    }
    renderLatestPage(true);

    const loadMoreBtn = $('#loadMoreBtn');
    const spinner = $('#loadSpinner');
    if (loadMoreBtn) {
      loadMoreBtn.addEventListener('click', () => {
        loadMoreBtn.disabled = true;
        spinner.hidden = false;
        setTimeout(() => {
          renderLatestPage(false);
          spinner.hidden = true;
          loadMoreBtn.disabled = false;
        }, 650);
      });
    }
  }

  function initMovieTabs() {
    const tabs = $('#movieTabs');
    if (!tabs) return;
    tabs.addEventListener('click', (e) => {
      const btn = e.target.closest('.tab');
      if (!btn) return;
      $$('.tab', tabs).forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
      btn.classList.add('active');
      btn.setAttribute('aria-selected', 'true');
      renderMovies(btn.dataset.tab);
    });
  }

  /* ---------------------------------------------------------------
     7. CARD INTERACTIONS: like / bookmark / share (event delegation)
  ------------------------------------------------------------------ */
  function initCardInteractions() {
    document.addEventListener('click', (e) => {
      const likeBtn = e.target.closest('.like-btn');
      if (likeBtn) {
        const countEl = likeBtn.querySelector('.like-count');
        const liked = likeBtn.classList.toggle('liked');
        let count = parseInt(countEl.textContent, 10) || 0;
        countEl.textContent = liked ? count + 1 : Math.max(0, count - 1);
        if (liked) showToast('Added to your likes', '❤');
        return;
      }
      const bookmarkBtn = e.target.closest('.bookmark-btn');
      if (bookmarkBtn) {
        const saved = bookmarkBtn.classList.toggle('saved');
        showToast(saved ? 'Saved to bookmarks' : 'Removed from bookmarks', '🔖');
        return;
      }
      const shareBtn = e.target.closest('.share-btn');
      if (shareBtn) {
        navigator.clipboard?.writeText(window.location.href).catch(() => {});
        showToast('Link copied to clipboard', '↗');
        return;
      }
    });
  }

  /* ---------------------------------------------------------------
     8. SIDEBAR
  ------------------------------------------------------------------ */
  function initSidebar() {
    initBlogsWidget();
    renderShorts();

    const insta = $('#instaGrid');
    if (insta) {
      insta.innerHTML = Array.from({ length: 6 }).map((_, i) => `<img src="${seedImg('insta' + i, 150, 150)}" alt="Instagram post ${i + 1}" loading="lazy">`).join('');
    }

    const facebookPosts = $('#facebookPosts');
    if (facebookPosts) {
      facebookPosts.innerHTML = NEWS.slice(0, 1).map(post => `
        <article class="facebook-post">
          <header class="facebook-post-head">
            <img src="assets/images/red_crab_logo.png" alt="" loading="lazy">
            <div><strong>RedCrab Entertainment</strong><span>Today · Public</span></div>
          </header>
          <img class="facebook-post-image" src="${post.img}" alt="${post.title}" loading="lazy">
          <div class="facebook-post-reaction"><span aria-hidden="true">👍</span> Like <span>·</span> Comment</div>
        </article>`).join('');
    }
  }

  function initWeather() {
    const temperature = $('#weatherTemp');
    const icon = $('#weatherIcon');
    const condition = $('#weatherCondition');
    const meta = $('#weatherMeta');
    const updated = $('#weatherUpdated');
    if (!temperature || !icon || !condition || !meta || !updated) return;

    const weatherDescriptions = {
      0: ['Clear sky', '☀️'],
      1: ['Mainly clear', '🌤️'],
      2: ['Partly cloudy', '⛅'],
      3: ['Overcast', '☁️'],
      45: ['Fog', '🌫️'],
      48: ['Depositing rime fog', '🌫️'],
      51: ['Light drizzle', '🌦️'],
      53: ['Moderate drizzle', '🌦️'],
      55: ['Dense drizzle', '🌧️'],
      56: ['Light freezing drizzle', '🌧️'],
      57: ['Dense freezing drizzle', '🌧️'],
      61: ['Slight rain', '🌦️'],
      63: ['Moderate rain', '🌧️'],
      65: ['Heavy rain', '🌧️'],
      66: ['Light freezing rain', '🌧️'],
      67: ['Heavy freezing rain', '🌧️'],
      71: ['Slight snow', '🌨️'],
      73: ['Moderate snow', '🌨️'],
      75: ['Heavy snow', '❄️'],
      77: ['Snow grains', '🌨️'],
      80: ['Slight rain showers', '🌦️'],
      81: ['Moderate rain showers', '🌧️'],
      82: ['Violent rain showers', '🌧️'],
      85: ['Slight snow showers', '🌨️'],
      86: ['Heavy snow showers', '❄️'],
      95: ['Thunderstorm', '⛈️'],
      96: ['Thunderstorm with slight hail', '⛈️'],
      99: ['Thunderstorm with heavy hail', '⛈️']
    };

    async function updateWeather() {
      condition.textContent = 'Loading current weather…';
      meta.textContent = '';
      updated.textContent = '';
      try {
        const response = await fetch('https://api.open-meteo.com/v1/forecast?latitude=20.2961&longitude=85.8245&current=temperature_2m%2Crelative_humidity_2m%2Capparent_temperature%2Cweather_code%2Cwind_speed_10m&timezone=Asia%2FKolkata');
        if (!response.ok) throw new Error(`Weather service returned HTTP ${response.status}.`);
        const data = await response.json();
        const current = data.current;
        if (!current || !Number.isFinite(current.temperature_2m) || !Number.isFinite(current.weather_code)) {
          throw new Error('Weather service returned incomplete current conditions.');
        }

        const [description, weatherIcon] = weatherDescriptions[current.weather_code] || ['Conditions unavailable', '🌡️'];
        temperature.textContent = `${Math.round(current.temperature_2m)}°C`;
        icon.textContent = weatherIcon;
        condition.textContent = description;

        const details = [];
        if (Number.isFinite(current.apparent_temperature)) details.push(`Feels like ${Math.round(current.apparent_temperature)}°C`);
        if (Number.isFinite(current.relative_humidity_2m)) details.push(`Humidity ${Math.round(current.relative_humidity_2m)}%`);
        if (Number.isFinite(current.wind_speed_10m)) details.push(`Wind ${Math.round(current.wind_speed_10m)} km/h`);
        meta.textContent = details.join(' · ');

        const observationTime = new Date(current.time);
        if (Number.isNaN(observationTime.getTime())) throw new Error('Weather service returned an invalid observation time.');
        updated.textContent = `Updated ${new Intl.DateTimeFormat('en-IN', {
          hour: 'numeric',
          minute: '2-digit',
          timeZone: 'Asia/Kolkata'
        }).format(observationTime)}`;
      } catch (error) {
        console.error('Unable to load Bhubaneswar weather:', error);
        condition.textContent = 'Weather currently unavailable.';
        meta.textContent = 'Please check your connection and try again later.';
        icon.textContent = '⚠️';
      }
    }

    updateWeather();
    window.setInterval(updateWeather, 15 * 60 * 1000);
  }

  /* ---------------------------------------------------------------
     9. LIVE UPDATES
  ------------------------------------------------------------------ */
  function initLiveUpdates() {
    const timeline = $('#liveTimeline');
    const refreshLabel = $('#liveRefresh');
    if (!timeline) return;
    let shown = 3;
    function render() {
      timeline.innerHTML = LIVE_UPDATES.slice(0, shown).map(u => `
        <li><div class="timeline-time">${u.time}</div><div class="timeline-text">${u.text}</div></li>
      `).join('');
    }
    render();
    setInterval(() => {
      refreshLabel.textContent = 'Refreshing…';
      setTimeout(() => {
        shown = Math.min(shown + 1, LIVE_UPDATES.length);
        render();
        refreshLabel.textContent = 'Auto-refreshing…';
      }, 500);
    }, 15000);
  }

  /* ---------------------------------------------------------------
     10. NEWSLETTER VALIDATION
  ------------------------------------------------------------------ */
  function initNewsletter() {
    const form = $('#newsletterForm');
    const input = $('#newsletterEmail');
    const msg = $('#newsletterMsg');
    if (!form) return;
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const value = input.value.trim();
      const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
      if (!valid) {
        input.classList.add('invalid');
        msg.textContent = 'Please enter a valid email address.';
        msg.className = 'newsletter-msg error';
        return;
      }
      input.classList.remove('invalid');
      msg.textContent = `Thanks! A confirmation has been sent to ${value}.`;
      msg.className = 'newsletter-msg success';
      form.reset();
      showToast('Subscribed successfully', '✓');
    });
    input.addEventListener('input', () => input.classList.remove('invalid'));
  }

  /* ---------------------------------------------------------------
     11. FAQ ACCORDION
  ------------------------------------------------------------------ */
  function initAccordion() {
    $$('.accordion-trigger').forEach(trigger => {
      trigger.addEventListener('click', () => {
        const panel = trigger.nextElementSibling;
        const isOpen = trigger.getAttribute('aria-expanded') === 'true';
        $$('.accordion-trigger').forEach(t => {
          t.setAttribute('aria-expanded', 'false');
          t.nextElementSibling.style.maxHeight = null;
        });
        if (!isOpen) {
          trigger.setAttribute('aria-expanded', 'true');
          panel.style.maxHeight = panel.scrollHeight + 'px';
        }
      });
    });
  }

  /* ---------------------------------------------------------------
     12. READING PROGRESS + BACK TO TOP
  ------------------------------------------------------------------ */
  function initScrollUI() {
    const progress = $('#readingProgress');
    const backToTop = $('#backToTop');
    window.addEventListener('scroll', () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const pct = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
      if (progress) progress.style.width = pct + '%';
      if (backToTop) backToTop.classList.toggle('show', scrollTop > 500);
    }, { passive: true });

    backToTop?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  /* ---------------------------------------------------------------
     13. LIGHTBOX
  ------------------------------------------------------------------ */
  function initLightbox() {
    const grid = $('#galleryGrid');
    const lightbox = $('#lightbox');
    const img = $('#lightboxImg');
    if (!grid || !lightbox) return;
    let index = 0;

    function open(i) {
      const photos = getGalleryPhotos();
      if (!photos[i]) return;
      index = i;
      img.src = photos[index].img.startsWith('data:') ? photos[index].img : photos[index].img.replace('/400/', '/1000/');
      img.alt = photos[index].caption;
      lightbox.classList.add('open');
      lightbox.setAttribute('aria-hidden', 'false');
    }
    function close() {
      lightbox.classList.remove('open');
      lightbox.setAttribute('aria-hidden', 'true');
    }
    function nav(delta) {
      const photos = getGalleryPhotos();
      index = (index + delta + photos.length) % photos.length;
      img.src = photos[index].img.startsWith('data:') ? photos[index].img : photos[index].img.replace('/400/', '/1000/');
      img.alt = photos[index].caption;
    }

    grid.addEventListener('click', (e) => {
      const item = e.target.closest('.masonry-item');
      if (item) open(Number(item.dataset.index));
    });
    grid.addEventListener('keydown', (e) => {
      const item = e.target.closest('.masonry-item');
      if (item && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); open(Number(item.dataset.index)); }
    });
    $('#lightboxClose').addEventListener('click', close);
    $('#lightboxPrev').addEventListener('click', () => nav(-1));
    $('#lightboxNext').addEventListener('click', () => nav(1));
    lightbox.addEventListener('click', (e) => { if (e.target === lightbox) close(); });
    document.addEventListener('keydown', (e) => {
      if (!lightbox.classList.contains('open')) return;
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowLeft') nav(-1);
      if (e.key === 'ArrowRight') nav(1);
    });
  }

  /* ---------------------------------------------------------------
     14. MISC (footer year, header shrink on scroll)
  ------------------------------------------------------------------ */
  function initMisc() {
    const yearEl = $('#footerYear');
    if (yearEl) yearEl.textContent = new Date().getFullYear();

  }

  /* ---------------------------------------------------------------
     15. INIT
  ------------------------------------------------------------------ */
  document.addEventListener('DOMContentLoaded', () => {
    initDate();
    initTicker();
    initThemeToggle();
    initHamburger();
    initSearch();
    initLiveTV();
    initHeroSlider();

    renderTrending();
    renderMovies('latest');
    initMovieTabs();
    renderOTT();
    initLatestNews();
    renderCelebs();
    renderGovEvents();
    renderEntEvents();
    renderVideos();
    renderOfficialYouTube();
    renderGallery();
    renderClients();
    renderAwards();
    renderInterviews();

    initCardInteractions();
    initSidebar();
    initWeather();
    initLiveUpdates();
    initNewsletter();
    initAccordion();
    initScrollUI();
    initLightbox();
    initVideoModalTriggers();
    initChatbot();
    initMisc();
  });
})();
const counters = document.querySelectorAll(".counter");

const startCounter = () => {

    counters.forEach(counter => {

        const target = +counter.getAttribute("data-target");

        let count = 0;

        const speed = target / 100;

        const updateCounter = () => {

            count += speed;

            if (count < target) {

                counter.innerText = Math.ceil(count);

                requestAnimationFrame(updateCounter);

            } else {

                counter.innerText = target + "+";

            }

        };

        updateCounter();

    });

};

startCounter();