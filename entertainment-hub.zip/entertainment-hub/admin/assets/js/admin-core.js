/* ============================================================
   ADMIN CORE — server-backed data layer, auth guard, shared shell.

   Data now lives in the PHP backend (api/index.php). The admin pages
   keep using the same synchronous helpers (ehLoad / ehSave / ehLog):
     - on page load, api/session.js.php injects window.__EH_BOOT with the
       signed-in user, a CSRF token and the saved site content;
     - ehLoad() reads that in-memory copy;
     - ehSave() updates the copy and syncs the changed sections to the
       server in the background (serial queue).
   Passwords never reach this file — they are hashed on the server.
   ============================================================ */

const EH_BOOT = window.__EH_BOOT || null;
const EH_SECTIONS = ['teams', 'galleryMedia', 'blogPosts', 'slides', 'social', 'liveStream', 'analytics'];

/* ---------- Default / seed data ---------- */
function ehDefaultTeams() {
  return [
    {
      id: 'team-1',
      name: 'Aarav Kumar',
      role: 'Editor-in-Chief',
      description: 'Leads the newsroom with a sharp eye for breaking stories and cultural trends.',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=600&auto=format&fit=crop'
    },
    {
      id: 'team-2',
      name: 'Simran Nair',
      role: 'Head of Content',
      description: 'Shapes every article, interview and feature with clarity and audience focus.',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=600&auto=format&fit=crop'
    },
    {
      id: 'team-3',
      name: 'Rohan Verma',
      role: 'Digital Strategist',
      description: 'Turns big ideas into timely coverage with a strong mix of insight and speed.',
      image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=600&auto=format&fit=crop'
    },
    {
      id: 'team-4',
      name: 'Nisha Rao',
      role: 'Senior Reporter',
      description: 'Tracks red-carpet events, award season buzz and the latest celebrity updates.',
      image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=600&auto=format&fit=crop'
    },
    {
      id: 'team-5',
      name: 'Dev Menon',
      role: 'Video Producer',
      description: 'Builds cinematic stories and fast-moving video content for our growing audience.',
      image: 'https://images.unsplash.com/photo-1504593811423-6dd665756598?w=600&auto=format&fit=crop'
    },
    {
      id: 'team-6',
      name: 'Priya Shah',
      role: 'Social Editor',
      description: 'Keeps every platform buzzing with sharp captions, trending topics and visuals.',
      image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=600&auto=format&fit=crop'
    },
    {
      id: 'team-7',
      name: 'Karan Dutta',
      role: 'Awards Specialist',
      description: 'Turns award season into timely, insightful coverage with expert context.',
      image: 'https://images.unsplash.com/photo-1507591064344-4c6ce005b128?w=600&auto=format&fit=crop'
    },
    {
      id: 'team-8',
      name: 'Meera Iyer',
      role: 'Interviews Lead',
      description: 'Crafts thoughtful conversations that bring creators and celebrities to life.',
      image: 'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=600&auto=format&fit=crop'
    },
    {
      id: 'team-9',
      name: 'Aditya Bose',
      role: 'Research Editor',
      description: 'Ensures every story is rich in detail, accurate and backed by strong sources.',
      image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=600&auto=format&fit=crop'
    },
    {
      id: 'team-10',
      name: 'Zara Malik',
      role: 'Community Manager',
      description: 'Connects our readers with the stories they care about through thoughtful engagement.',
      image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=600&auto=format&fit=crop'
    }
  ];
}

function ehDefaultData() {
  const today = new Date();
  const visitors = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    visitors.push({
      date: d.toISOString().slice(0, 10),
      count: Math.floor(1200 + Math.random() * 2600)
    });
  }
  return {
    social: {
      instagramId: 'redcrabentertainment.official',
      facebookId: 'RedCrabEntertainmentOfficial',
      youtubeChannelId: 'UC_RedCrabEntertainment'
    },
    liveStream: null,
    teams: ehDefaultTeams(),
    galleryMedia: { photos: [], videos: [], shorts: [] },
    blogPosts: [],
    slides: [
      {
        id: 's1',
        title: 'Zeenat: Rise of the Phoenix — First Look',
        tagline: 'Trending',
        category: 'Movies',
        date: 'Oct 3, 2026',
        readTime: 3,
        views: 4250,
        image: 'https://picsum.photos/seed/slide1/900/500',
        instagramPostId: 'Cz1eXaMpLe1',
        facebookPostId: 'fb.post.1001',
        createdAt: new Date(Date.now() - 3 * 86400000).toISOString()
      },
      {
        id: 's2',
        title: 'Cannes Red Carpet: Best Dressed 2026',
        tagline: 'Trending',
        category: 'Awards',
        date: 'Oct 2, 2026',
        readTime: 4,
        views: 3180,
        image: 'https://picsum.photos/seed/slide2/900/500',
        instagramPostId: 'Cz2eXaMpLe2',
        facebookPostId: 'fb.post.1002',
        createdAt: new Date(Date.now() - 1 * 86400000).toISOString()
      }
    ],
    analytics: {
      visitors,
      facebookFollowers: 184200,
      instagramFollowers: 312500,
      youtubeSubscribers: 96400,
      youtubeComments: 5342,
      dailyUploads: 6
    }
  };
}

/* ---------- API helper ---------- */
async function ehApi(action, body, method) {
  const verb = method || (body === undefined ? 'GET' : 'POST');
  const headers = { 'Accept': 'application/json' };
  if (verb !== 'GET') {
    headers['Content-Type'] = 'application/json';
    headers['X-CSRF-Token'] = (EH_BOOT && EH_BOOT.csrf) || '';
  }
  let response;
  try {
    response = await fetch(`${EH_BOOT.apiUrl}?action=${encodeURIComponent(action)}`, {
      method: verb,
      credentials: 'same-origin',
      headers,
      body: verb === 'GET' ? undefined : JSON.stringify(body || {})
    });
  } catch (networkError) {
    const err = new Error('Cannot reach the server. Check your connection.');
    err.status = 0;
    throw err;
  }
  let data = {};
  try { data = await response.json(); } catch (e) { /* non-JSON error page */ }
  if (!response.ok) {
    const err = new Error(data.error || `Request failed (${response.status}).`);
    err.status = response.status;
    throw err;
  }
  if (data && data.csrf && EH_BOOT) EH_BOOT.csrf = data.csrf;
  return data;
}

/* ---------- In-memory copy of server content ---------- */
let ehCache = null;
let ehPending = {};
let ehFlushPromise = null;
let ehLogPromise = Promise.resolve();
let ehActivityLog = [];

function ehClone(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

function ehInitState() {
  if (ehCache) return;
  ehCache = {};
  const state = (EH_BOOT && EH_BOOT.state) || {};
  const saved = state.content || {};
  const defaults = ehDefaultData();
  const isSuper = EH_BOOT && EH_BOOT.user && EH_BOOT.user.role === 'superadmin';
  const seed = {};
  EH_SECTIONS.forEach(name => {
    if (Object.prototype.hasOwnProperty.call(saved, name)) {
      ehCache[name] = saved[name];
    } else {
      ehCache[name] = defaults[name];
      // First visit: store the starter content once (sub-admins cannot create the social IDs).
      if (defaults[name] !== null && (name !== 'social' || isSuper)) seed[name] = ehClone(defaults[name]);
    }
  });
  ehActivityLog = Array.isArray(state.activityLog) ? state.activityLog : [];
  ehCache.__authEvents = Array.isArray(state.authEvents) ? state.authEvents : [];
  if (Object.keys(seed).length) {
    Object.assign(ehPending, seed);
    ehScheduleFlush();
  }
}

function ehLoad() {
  ehInitState();
  const data = {};
  EH_SECTIONS.forEach(name => { data[name] = ehClone(ehCache[name]); });
  data.activityLog = ehClone(ehActivityLog);
  data.authEvents = ehClone(ehCache.__authEvents);
  const user = (EH_BOOT && EH_BOOT.user) || {};
  data.auth = { username: user.username || '', email: user.email || '' };
  data.session = !!(EH_BOOT && EH_BOOT.authenticated);
  data.sessionUser = user.username || '';
  data.sessionRole = user.role || '';
  return data;
}

function ehSave(data) {
  ehInitState();
  EH_SECTIONS.forEach(name => {
    if (!(name in data)) return;
    const next = JSON.stringify(data[name]);
    if (next === JSON.stringify(ehCache[name])) return;
    ehCache[name] = ehClone(data[name]);
    ehPending[name] = ehClone(data[name]);
  });
  return ehScheduleFlush();
}

function ehScheduleFlush() {
  if (!ehFlushPromise) {
    ehFlushPromise = ehFlush().finally(() => { ehFlushPromise = null; });
  }
  return ehFlushPromise;
}

async function ehFlush() {
  // microtask delay so several ehSave() calls in the same tick go out as one request
  await Promise.resolve();
  while (Object.keys(ehPending).length) {
    const batch = ehPending;
    ehPending = {};
    const sent = {};
    Object.keys(batch).forEach(name => { sent[name] = JSON.stringify(batch[name]); });
    try {
      const result = await ehApi('save', { sections: batch });
      const normalized = result.content || {};
      Object.keys(normalized).forEach(name => {
        // The server swaps uploaded base64 images for short file URLs; adopt that
        // version if nothing changed locally in the meantime.
        if (!(name in ehPending) && JSON.stringify(ehCache[name]) === sent[name]) {
          ehCache[name] = normalized[name];
        }
      });
    } catch (error) {
      ehHandleSyncError(error);
      return;
    }
  }
}

function ehHandleSyncError(error) {
  if (error.status === 401) {
    window.location.href = 'login.html';
    return;
  }
  ehShowBanner(`Your last change could not be saved: ${error.message}`);
}

function ehShowBanner(message) {
  let banner = document.getElementById('ehSyncBanner');
  if (!banner) {
    banner = document.createElement('div');
    banner.id = 'ehSyncBanner';
    banner.className = 'admin-sync-banner';
    banner.setAttribute('role', 'alert');
    document.body.appendChild(banner);
  }
  banner.textContent = message + ' (click to dismiss)';
  banner.onclick = () => banner.remove();
}

/** Resolves when every queued save/log has reached the server (use before reloading/redirecting). */
async function ehIdle() {
  while (ehFlushPromise || Object.keys(ehPending).length) {
    await ehScheduleFlush();
  }
  await ehLogPromise;
}

window.addEventListener('beforeunload', event => {
  if (ehFlushPromise || (ehPending && Object.keys(ehPending).length)) {
    event.preventDefault();
    event.returnValue = '';
  }
});

function ehLog(action) {
  ehActivityLog.unshift({ time: new Date().toISOString(), action });
  ehActivityLog = ehActivityLog.slice(0, 50);
  ehLogPromise = ehLogPromise
    .then(() => ehApi('log', { action }))
    .catch(error => { if (error.status === 401) ehHandleSyncError(error); });
  return ehLogPromise;
}

async function ehResetDemoData() {
  await ehIdle();
  await ehApi('reset_content', {});
}

/* ---------- Auth guard ---------- */
function ehRequireAuth() {
  if (!EH_BOOT || !EH_BOOT.authenticated) {
    window.location.href = 'login.html';
    return false;
  }
  if (window.location.pathname.toLowerCase().endsWith('/settings.html') && EH_BOOT.user.role !== 'superadmin') {
    window.alert('Only the super admin can manage admin accounts and settings.');
    window.location.href = 'index.html';
    return false;
  }
  return true;
}

async function ehLogout() {
  try {
    await ehIdle();
    await ehApi('logout', {});
  } catch (error) {
    /* even if the request fails, leave the panel */
  }
  window.location.href = 'login.html';
}

function ehProcessProfilePhoto(file) {
  return new Promise((resolve, reject) => {
    if (!file || !['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      reject(new Error('Choose a JPG, PNG, or WebP image.'));
      return;
    }
    if (file.size > 4 * 1024 * 1024) {
      reject(new Error('Choose an image smaller than 4 MB.'));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('The profile photo could not be read.'));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error('The selected file is not a readable image.'));
      image.onload = () => {
        const maxDimension = 256;
        const scale = Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        const context = canvas.getContext('2d');
        if (!context) {
          reject(new Error('Profile photo processing is unavailable in this browser.'));
          return;
        }
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        try {
          resolve(canvas.toDataURL('image/jpeg', 0.8));
        } catch {
          reject(new Error('The profile photo could not be processed.'));
        }
      };
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

function ehInitThemeToggle() {
  const toggle = document.getElementById('ehThemeToggle');
  const dark = localStorage.getItem('eh_admin_theme') === 'dark';
  document.documentElement.dataset.adminTheme = dark ? 'dark' : 'light';
  if (!toggle) return;

  function renderToggle() {
    const isDark = document.documentElement.dataset.adminTheme === 'dark';
    toggle.innerHTML = `<span aria-hidden="true">${isDark ? '☀️' : '🌙'}</span><span>${isDark ? 'Light mode' : 'Dark mode'}</span>`;
    toggle.setAttribute('aria-label', `Switch to ${isDark ? 'light' : 'dark'} mode`);
    toggle.setAttribute('aria-pressed', String(isDark));
  }

  renderToggle();
  toggle.addEventListener('click', () => {
    const nextTheme = document.documentElement.dataset.adminTheme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('eh_admin_theme', nextTheme);
    document.documentElement.dataset.adminTheme = nextTheme;
    renderToggle();
  });
}

/* ---------- Formatting helpers ---------- */
function ehFormatNumber(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
  return String(n);
}

function ehTimeAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return mins + 'm ago';
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return hrs + 'h ago';
  const days = Math.floor(hrs / 24);
  return days + 'd ago';
}

/* ---------- Shared shell: sidebar + topbar ---------- */
const EH_NAV_ITEMS = [
  { page: 'dashboard', href: 'index.html', icon: '📊', label: 'Dashboard' },
  { page: 'teams', href: 'teams.html', icon: '👥', label: 'Team' },
  { page: 'slides', href: 'slides.html', icon: '🖼️', label: 'Slides & Social' },
  { page: 'gallery', href: 'gallery.html', icon: '🎞️', label: 'Gallery' },
  { page: 'blogs', href: 'blogs.html', icon: '📝', label: 'Blogs' },
  { page: 'analytics', href: 'analytics.html', icon: '📈', label: 'Analytics' },
  { page: 'database', href: 'database.html', icon: '🗄️', label: 'Database' },
  { page: 'settings', href: 'settings.html', icon: '⚙️', label: 'Settings' }
];

function ehRenderShell(activePage, pageTitle) {
  const data = ehLoad();
  const currentAdmin = data.sessionUser || data.auth.username || 'Admin';
  const currentAdminAccount = (EH_BOOT && EH_BOOT.user) || null;

  const visibleNavItems = data.sessionRole === 'superadmin'
    ? EH_NAV_ITEMS
    : EH_NAV_ITEMS.filter(item => item.page !== 'settings');
  const navHtml = visibleNavItems.map(item => `
    <a href="${item.href}" class="admin-nav-link ${item.page === activePage ? 'active' : ''}">
      <span class="admin-nav-icon">${item.icon}</span>
      <span>${item.label}</span>
    </a>`).join('');

  const shellHtml = `
    <aside class="admin-sidebar" id="adminSidebar">
      <a href="index.html" class="admin-logo">
        <img src="../assets/images/red_crab_logo.png" class="admin-brand-image" alt="RedCrab Entertainment">
      </a>
      <span class="admin-logo-tag">Admin Panel</span>
      <nav class="admin-nav">${navHtml}</nav>
      <div class="admin-sidebar-footer">
        <a href="../index.html" class="admin-nav-link admin-view-site">
          <span class="admin-nav-icon">🌐</span><span>View Live Site</span>
        </a>
        <button class="admin-nav-link admin-logout-btn" id="ehLogoutBtn">
          <span class="admin-nav-icon">🚪</span><span>Logout</span>
        </button>
      </div>
    </aside>

    <div class="admin-main">
      <header class="admin-topbar">
        <button class="admin-menu-toggle" id="ehMenuToggle" aria-label="Toggle menu">☰</button>
        <h1 class="admin-page-title">${pageTitle}</h1>
        <div class="admin-topbar-right">
          <button class="admin-theme-toggle" id="ehThemeToggle" type="button" aria-label="Toggle admin color theme"></button>
          <div class="admin-user-chip">
            <span class="admin-user-avatar">${currentAdmin.charAt(0).toUpperCase()}</span>
            <span class="admin-user-name">Signed in as ${currentAdmin}</span>
          </div>
        </div>
      </header>
      <div class="admin-content" id="adminContent"></div>
    </div>
  `;

  document.getElementById('adminShell').innerHTML = shellHtml;
  const userAvatar = document.querySelector('.admin-user-avatar');
  if (currentAdminAccount && currentAdminAccount.profilePhoto) {
    const avatarImage = document.createElement('img');
    avatarImage.src = currentAdminAccount.profilePhoto;
    avatarImage.alt = `${currentAdmin} profile photo`;
    userAvatar.replaceChildren(avatarImage);
    userAvatar.classList.add('has-photo');
  }
  ehInitThemeToggle();

  document.getElementById('ehLogoutBtn').addEventListener('click', ehLogout);
  document.getElementById('ehMenuToggle').addEventListener('click', () => {
    document.getElementById('adminSidebar').classList.toggle('open');
  });
}

/* Init year in case footer used anywhere */
document.addEventListener('DOMContentLoaded', () => {
  const y = document.getElementById('ehYear');
  if (y) y.textContent = new Date().getFullYear();
});
